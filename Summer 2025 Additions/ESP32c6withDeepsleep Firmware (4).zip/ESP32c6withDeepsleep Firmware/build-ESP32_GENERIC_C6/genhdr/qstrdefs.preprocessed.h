# 0 "<stdin>"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "<stdin>"
# 29 "<stdin>"
# 1 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/py/mpconfig.h" 1
# 91 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/py/mpconfig.h"
# 1 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h" 1




# 1 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/boards/ESP32_GENERIC_C6/mpconfigboard.h" 1
# 6 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h" 2

# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stdint.h" 1 3 4
# 9 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stdint.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdint.h" 1 3 4
# 12 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdint.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 1 3 4







# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/features.h" 1 3 4
# 28 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/features.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/_newlib_version.h" 1 3 4
# 29 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/features.h" 2 3 4
# 9 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 2 3 4
# 41 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 3 4

# 41 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 3 4
typedef signed char __int8_t;

typedef unsigned char __uint8_t;
# 55 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 3 4
typedef short int __int16_t;

typedef short unsigned int __uint16_t;
# 77 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 3 4
typedef long int __int32_t;

typedef long unsigned int __uint32_t;
# 103 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 3 4
typedef long long int __int64_t;

typedef long long unsigned int __uint64_t;
# 134 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 3 4
typedef signed char __int_least8_t;

typedef unsigned char __uint_least8_t;
# 160 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 3 4
typedef short int __int_least16_t;

typedef short unsigned int __uint_least16_t;
# 182 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 3 4
typedef long int __int_least32_t;

typedef long unsigned int __uint_least32_t;
# 200 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 3 4
typedef long long int __int_least64_t;

typedef long long unsigned int __uint_least64_t;
# 214 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_default_types.h" 3 4
typedef long long int __intmax_t;







typedef long long unsigned int __uintmax_t;







typedef int __intptr_t;

typedef unsigned int __uintptr_t;
# 13 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdint.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_intsup.h" 1 3 4
# 35 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_intsup.h" 3 4
       
       
       
       
       
       
       
       
# 190 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_intsup.h" 3 4
       
       
       
       
       
       
       
       
# 14 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdint.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_stdint.h" 1 3 4
# 20 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_stdint.h" 3 4
typedef __int8_t int8_t ;



typedef __uint8_t uint8_t ;







typedef __int16_t int16_t ;



typedef __uint16_t uint16_t ;







typedef __int32_t int32_t ;



typedef __uint32_t uint32_t ;







typedef __int64_t int64_t ;



typedef __uint64_t uint64_t ;






typedef __intmax_t intmax_t;




typedef __uintmax_t uintmax_t;




typedef __intptr_t intptr_t;




typedef __uintptr_t uintptr_t;
# 15 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdint.h" 2 3 4






typedef __int_least8_t int_least8_t;
typedef __uint_least8_t uint_least8_t;




typedef __int_least16_t int_least16_t;
typedef __uint_least16_t uint_least16_t;




typedef __int_least32_t int_least32_t;
typedef __uint_least32_t uint_least32_t;




typedef __int_least64_t int_least64_t;
typedef __uint_least64_t uint_least64_t;
# 51 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdint.h" 3 4
  typedef int int_fast8_t;
  typedef unsigned int uint_fast8_t;
# 61 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdint.h" 3 4
  typedef int int_fast16_t;
  typedef unsigned int uint_fast16_t;
# 71 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdint.h" 3 4
  typedef int int_fast32_t;
  typedef unsigned int uint_fast32_t;
# 81 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdint.h" 3 4
  typedef long long int int_fast64_t;
  typedef long long unsigned int uint_fast64_t;
# 10 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stdint.h" 2 3 4
# 8 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h" 2
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/alloca.h" 1 3 4
# 10 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/alloca.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/_ansi.h" 1 3 4
# 10 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/_ansi.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/newlib.h" 1 3 4
# 11 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/_ansi.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/config.h" 1 3 4



# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/ieeefp.h" 1 3 4
# 5 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/config.h" 2 3 4
# 12 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/_ansi.h" 2 3 4
# 11 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/alloca.h" 2 3 4
# 1 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/reent.h" 1 3 4






       
# 22 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/reent.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 1 3 4
# 13 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/_ansi.h" 1 3 4
# 14 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 145 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 3 4
typedef int ptrdiff_t;
# 214 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 3 4
typedef unsigned int size_t;
# 329 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 3 4
typedef int wchar_t;
# 425 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 3 4
} max_align_t;
# 15 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_types.h" 1 3 4
# 24 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_types.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 359 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 3 4
typedef unsigned int wint_t;
# 25 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_types.h" 2 3 4


# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_types.h" 1 3 4
# 28 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_types.h" 2 3 4


typedef long __blkcnt_t;



typedef long __blksize_t;



typedef __uint64_t __fsblkcnt_t;



typedef __uint32_t __fsfilcnt_t;



typedef long _off_t;





typedef int __pid_t;



typedef short __dev_t;



typedef unsigned short __uid_t;


typedef unsigned short __gid_t;



typedef __uint32_t __id_t;







typedef unsigned short __ino_t;
# 90 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_types.h" 3 4
typedef __uint32_t __mode_t;





__extension__ typedef long long _off64_t;





typedef _off_t __off_t;


typedef _off64_t __loff_t;


typedef long __key_t;







typedef long _fpos_t;
# 131 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_types.h" 3 4
typedef unsigned int __size_t;
# 147 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_types.h" 3 4
typedef signed int _ssize_t;
# 158 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_types.h" 3 4
typedef _ssize_t __ssize_t;



typedef struct
{
  int __count;
  union
  {
    wint_t __wch;
    unsigned char __wchb[4];
  } __value;
} _mbstate_t;




typedef void *_iconv_t;






typedef unsigned long __clock_t;






typedef __int_least64_t __time_t;





typedef unsigned long __clockid_t;


typedef long __daddr_t;



typedef unsigned long __timer_t;


typedef __uint8_t __sa_family_t;



typedef __uint32_t __socklen_t;


typedef int __nl_item;
typedef unsigned short __nlink_t;
typedef long __suseconds_t;
typedef unsigned long __useconds_t;







typedef __builtin_va_list __va_list;
# 16 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 2 3 4






typedef unsigned long __ULong;
# 34 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 3 4
# 1 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/lock.h" 1 3 4





       

# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/lock.h" 1 3 4
# 33 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/lock.h" 3 4
struct __lock;
typedef struct __lock * _LOCK_T;






extern void __retarget_lock_init(_LOCK_T *lock);

extern void __retarget_lock_init_recursive(_LOCK_T *lock);

extern void __retarget_lock_close(_LOCK_T lock);

extern void __retarget_lock_close_recursive(_LOCK_T lock);

extern void __retarget_lock_acquire(_LOCK_T lock);

extern void __retarget_lock_acquire_recursive(_LOCK_T lock);

extern int __retarget_lock_try_acquire(_LOCK_T lock);

extern int __retarget_lock_try_acquire_recursive(_LOCK_T lock);


extern void __retarget_lock_release(_LOCK_T lock);

extern void __retarget_lock_release_recursive(_LOCK_T lock);
# 9 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/lock.h" 2 3 4
# 23 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/lock.h" 3 4
struct __lock {
   int reserved[23];
};







typedef _LOCK_T _lock_t;

void _lock_init(_lock_t *plock);
void _lock_init_recursive(_lock_t *plock);
void _lock_close(_lock_t *plock);
void _lock_close_recursive(_lock_t *plock);
void _lock_acquire(_lock_t *plock);
void _lock_acquire_recursive(_lock_t *plock);
int _lock_try_acquire(_lock_t *plock);
int _lock_try_acquire_recursive(_lock_t *plock);
void _lock_release(_lock_t *plock);
void _lock_release_recursive(_lock_t *plock);
# 35 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 2 3 4
typedef _LOCK_T _flock_t;







struct _reent;

struct __locale_t;






struct _Bigint
{
  struct _Bigint *_next;
  int _k, _maxwds, _sign, _wds;
  __ULong _x[1];
};


struct __tm
{
  int __tm_sec;
  int __tm_min;
  int __tm_hour;
  int __tm_mday;
  int __tm_mon;
  int __tm_year;
  int __tm_wday;
  int __tm_yday;
  int __tm_isdst;
};







struct _on_exit_args {
 void * _fnargs[32];
 void * _dso_handle[32];

 __ULong _fntypes;


 __ULong _is_cxa;
};


struct _atexit {
 struct _atexit *_next;
 int _ind;
 void (*_fns[32])(void);
        struct _on_exit_args * _on_exit_args_ptr;
};
# 115 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 3 4
struct __sbuf {
 unsigned char *_base;
 int _size;
};
# 152 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 3 4
struct __sFILE {
  unsigned char *_p;
  int _r;
  int _w;
  short _flags;
  short _file;
  struct __sbuf _bf;
  int _lbfsize;


  struct _reent *_data;



  void * _cookie;

  _ssize_t (*_read) (struct _reent *, void *,
        char *, int);
  _ssize_t (*_write) (struct _reent *, void *,
         const char *,
         int);
  _fpos_t (*_seek) (struct _reent *, void *, _fpos_t, int);
  int (*_close) (struct _reent *, void *);


  struct __sbuf _ub;
  unsigned char *_up;
  int _ur;


  unsigned char _ubuf[3];
  unsigned char _nbuf[1];


  struct __sbuf _lb;


  int _blksize;
  _off_t _offset;






  _flock_t _lock;

  _mbstate_t _mbstate;
  int _flags2;
};
# 269 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 3 4
typedef struct __sFILE __FILE;



extern __FILE __sf[3];

struct _glue
{
  struct _glue *_next;
  int _niobs;
  __FILE *_iobs;
};

extern struct _glue __sglue;
# 305 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 3 4
struct _rand48 {
  unsigned short _seed[3];
  unsigned short _mult[3];
  unsigned short _add;


  __extension__ unsigned long long _rand_next;

};
# 347 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 3 4
struct _mprec
{

  struct _Bigint *_result;
  int _result_k;
  struct _Bigint *_p5s;
  struct _Bigint **_freelist;
};


struct _misc_reent
{

  char *_strtok_last;
  _mbstate_t _mblen_state;
  _mbstate_t _wctomb_state;
  _mbstate_t _mbtowc_state;
  char _l64a_buf[8];
  int _getdate_err;
  _mbstate_t _mbrlen_state;
  _mbstate_t _mbrtowc_state;
  _mbstate_t _mbsrtowcs_state;
  _mbstate_t _wcrtomb_state;
  _mbstate_t _wcsrtombs_state;
};



struct _reent
{


  int _errno;




  __FILE *_stdin, *_stdout, *_stderr;

  int _inc;

  char *_emergency;


  int _reserved_0;
  int _reserved_1;

  struct __locale_t *_locale;

  struct _mprec *_mp;

  void (*__cleanup) (struct _reent *);

  int _gamma_signgam;


  int _cvtlen;
  char *_cvtbuf;

  struct _rand48 *_r48;
  struct __tm *_localtime_buf;
  char *_asctime_buf;


  void (** _sig_func)(int);


  struct _atexit *_reserved_6;
  struct _atexit _reserved_7;
  struct _glue _reserved_8;


  __FILE *__sf;
  struct _misc_reent *_misc;
  char *_signal_buf;
};
# 458 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 3 4
# 1 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/assert.h" 1 3 4
# 11 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/assert.h" 3 4
       
# 1 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/build-ESP32_GENERIC_C6/config/sdkconfig.h" 1 3 4




       
# 13 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/assert.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 1 3 4
# 10 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/ieeefp.h" 1 3 4
# 11 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 2 3 4





# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 17 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 2 3 4


# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/cdefs.h" 1 3 4
# 47 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/cdefs.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 48 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/cdefs.h" 2 3 4
# 20 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/stdlib.h" 1 3 4
# 21 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 2 3 4

# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/alloca.h" 1 3 4
# 23 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 2 3 4
# 33 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 3 4


typedef struct
{
  int quot;
  int rem;
} div_t;

typedef struct
{
  long quot;
  long rem;
} ldiv_t;


typedef struct
{
  long long int quot;
  long long int rem;
} lldiv_t;




typedef int (*__compar_fn_t) (const void *, const void *);







int __locale_mb_cur_max (void);



void abort (void) __attribute__ ((__noreturn__));
int abs (int);

__uint32_t arc4random (void);
__uint32_t arc4random_uniform (__uint32_t);
void arc4random_buf (void *, size_t);

int atexit (void (*__func)(void));
double atof (const char *__nptr);

float atoff (const char *__nptr);

int atoi (const char *__nptr);
int _atoi_r (struct _reent *, const char *__nptr);
long atol (const char *__nptr);
long _atol_r (struct _reent *, const char *__nptr);
void * bsearch (const void *__key,
         const void *__base,
         size_t __nmemb,
         size_t __size,
         __compar_fn_t _compar);
void *calloc(size_t, size_t) __attribute__((__malloc__)) __attribute__((__warn_unused_result__))
      __attribute__((__alloc_size__(1, 2))) ;
div_t div (int __numer, int __denom);
void exit (int __status) __attribute__ ((__noreturn__));
void free (void *) ;
char * getenv (const char *__string);
char * _getenv_r (struct _reent *, const char *__string);



char * _findenv (const char *, int *);
char * _findenv_r (struct _reent *, const char *, int *);

extern char *suboptarg;
int getsubopt (char **, char * const *, char **);

long labs (long);
ldiv_t ldiv (long __numer, long __denom);
void *malloc(size_t) __attribute__((__malloc__)) __attribute__((__warn_unused_result__)) __attribute__((__alloc_size__(1))) ;
int mblen (const char *, size_t);
int _mblen_r (struct _reent *, const char *, size_t, _mbstate_t *);
int mbtowc (wchar_t *restrict, const char *restrict, size_t);
int _mbtowc_r (struct _reent *, wchar_t *restrict, const char *restrict, size_t, _mbstate_t *);
int wctomb (char *, wchar_t);
int _wctomb_r (struct _reent *, char *, wchar_t, _mbstate_t *);
size_t mbstowcs (wchar_t *restrict, const char *restrict, size_t);
size_t _mbstowcs_r (struct _reent *, wchar_t *restrict, const char *restrict, size_t, _mbstate_t *);
size_t wcstombs (char *restrict, const wchar_t *restrict, size_t);
size_t _wcstombs_r (struct _reent *, char *restrict, const wchar_t *restrict, size_t, _mbstate_t *);


char * mkdtemp (char *);






int mkstemp (char *);


int mkstemps (char *, int);


char * mktemp (char *) __attribute__ ((__deprecated__("the use of `mktemp' is dangerous; use `mkstemp' instead")));


char * _mkdtemp_r (struct _reent *, char *);
int _mkostemp_r (struct _reent *, char *, int);
int _mkostemps_r (struct _reent *, char *, int, int);
int _mkstemp_r (struct _reent *, char *);
int _mkstemps_r (struct _reent *, char *, int);
char * _mktemp_r (struct _reent *, char *) __attribute__ ((__deprecated__("the use of `mktemp' is dangerous; use `mkstemp' instead")));
void qsort (void *__base, size_t __nmemb, size_t __size, __compar_fn_t _compar);
int rand (void);
void *realloc(void *, size_t) __attribute__((__warn_unused_result__)) __attribute__((__alloc_size__(2))) ;

void *reallocarray(void *, size_t, size_t) __attribute__((__warn_unused_result__)) __attribute__((__alloc_size__(2, 3)));
void *reallocf(void *, size_t) __attribute__((__warn_unused_result__)) __attribute__((__alloc_size__(2)));


char * realpath (const char *restrict path, char *restrict resolved_path);


int rpmatch (const char *response);




void srand (unsigned __seed);
double strtod (const char *restrict __n, char **restrict __end_PTR);
double _strtod_r (struct _reent *,const char *restrict __n, char **restrict __end_PTR);

float strtof (const char *restrict __n, char **restrict __end_PTR);







long strtol (const char *restrict __n, char **restrict __end_PTR, int __base);
long _strtol_r (struct _reent *,const char *restrict __n, char **restrict __end_PTR, int __base);
unsigned long strtoul (const char *restrict __n, char **restrict __end_PTR, int __base);
unsigned long _strtoul_r (struct _reent *,const char *restrict __n, char **restrict __end_PTR, int __base);
# 191 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 3 4
int system (const char *__string);


long a64l (const char *__input);
char * l64a (long __input);
char * _l64a_r (struct _reent *,long __input);


int on_exit (void (*__func)(int, void *),void *__arg);


void _Exit (int __status) __attribute__ ((__noreturn__));


int putenv (char *__string);

int _putenv_r (struct _reent *, char *__string);
void * _reallocf_r (struct _reent *, void *, size_t);

int setenv (const char *__string, const char *__value, int __overwrite);

int _setenv_r (struct _reent *, const char *__string, const char *__value, int __overwrite);
# 224 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 3 4
char * __itoa (int, char *, int);
char * __utoa (unsigned, char *, int);

char * itoa (int, char *, int);
char * utoa (unsigned, char *, int);


int rand_r (unsigned *__seed);



double drand48 (void);
double _drand48_r (struct _reent *);
double erand48 (unsigned short [3]);
double _erand48_r (struct _reent *, unsigned short [3]);
long jrand48 (unsigned short [3]);
long _jrand48_r (struct _reent *, unsigned short [3]);
void lcong48 (unsigned short [7]);
void _lcong48_r (struct _reent *, unsigned short [7]);
long lrand48 (void);
long _lrand48_r (struct _reent *);
long mrand48 (void);
long _mrand48_r (struct _reent *);
long nrand48 (unsigned short [3]);
long _nrand48_r (struct _reent *, unsigned short [3]);
unsigned short *
       seed48 (unsigned short [3]);
unsigned short *
       _seed48_r (struct _reent *, unsigned short [3]);
void srand48 (long);
void _srand48_r (struct _reent *, long);


char * initstate (unsigned, char *, size_t);
long random (void);
char * setstate (char *);
void srandom (unsigned);


long long atoll (const char *__nptr);

long long _atoll_r (struct _reent *, const char *__nptr);

long long llabs (long long);
lldiv_t lldiv (long long __numer, long long __denom);
long long strtoll (const char *restrict __n, char **restrict __end_PTR, int __base);

long long _strtoll_r (struct _reent *, const char *restrict __n, char **restrict __end_PTR, int __base);

unsigned long long strtoull (const char *restrict __n, char **restrict __end_PTR, int __base);

unsigned long long _strtoull_r (struct _reent *, const char *restrict __n, char **restrict __end_PTR, int __base);



void cfree (void *);


int unsetenv (const char *__string);

int _unsetenv_r (struct _reent *, const char *__string);



int posix_memalign (void **, size_t, size_t) __attribute__((__nonnull__ (1)))
     __attribute__((__warn_unused_result__));


char * _dtoa_r (struct _reent *, double, int, int, int *, int*, char**);

void * _malloc_r (struct _reent *, size_t) ;
void * _calloc_r (struct _reent *, size_t, size_t) ;
void _free_r (struct _reent *, void *) ;
void * _realloc_r (struct _reent *, void *, size_t) ;
void _mstats_r (struct _reent *, char *);

int _system_r (struct _reent *, const char *);

void __eprintf (const char *, const char *, unsigned int, const char *);
# 312 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 3 4
void qsort_r (void *__base, size_t __nmemb, size_t __size, void *__thunk, int (*_compar)(void *, const void *, const void *))
             __asm__ ("" "__bsd_qsort_r");
# 322 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdlib.h" 3 4
extern long double _strtold_r (struct _reent *, const char *restrict, char **restrict);

extern long double strtold (const char *restrict, char **restrict);







void * aligned_alloc(size_t, size_t) __attribute__((__malloc__)) __attribute__((__alloc_align__(1)))
     __attribute__((__alloc_size__(2))) __attribute__((__warn_unused_result__));
int at_quick_exit(void (*)(void));
_Noreturn void
 quick_exit(int);



# 14 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/assert.h" 2 3 4


# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/assert.h" 1 3 4
# 39 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/assert.h" 3 4
void __assert (const char *, int, const char *)
     __attribute__ ((__noreturn__));
void __assert_func (const char *, int, const char *, const char *)
     __attribute__ ((__noreturn__));
# 17 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/assert.h" 2 3 4
# 459 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 2 3 4
# 765 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 3 4
extern struct _reent *_impure_ptr ;





extern struct _reent _impure_data ;





  struct _reent * __getreent (void);
# 883 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/reent.h" 3 4
extern struct _atexit *__atexit;
extern struct _atexit __atexit0;

extern void (*__stdio_exit_handler) (void);

void _reclaim_reent (struct _reent *);

extern int _fwalk_sglue (struct _reent *, int (*)(struct _reent *, __FILE *),
    struct _glue *);
# 23 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/reent.h" 2 3 4
# 31 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/reent.h" 3 4
extern void __sinit (struct _reent *);

extern struct _glue __sglue;
extern struct _reent * _global_impure_ptr;
# 12 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/alloca.h" 2 3 4
# 9 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_random.h" 1
# 10 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_random.h"
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 11 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_random.h" 2
# 30 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_random.h"

# 30 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_random.h"
uint32_t esp_random(void);
# 41 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_random.h"
void esp_fill_random(void *buf, size_t len);
# 10 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h" 1
# 11 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h"
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stdbool.h" 1 3 4
# 12 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_err.h" 1






       


# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 1 3 4
# 36 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 37 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 2 3 4



# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stdarg.h" 1 3 4
# 40 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stdarg.h" 3 4

# 40 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 41 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 2 3 4





typedef __gnuc_va_list va_list;
# 63 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4



typedef __FILE FILE;



typedef _fpos_t fpos_t;





typedef __off_t off_t;




typedef _ssize_t ssize_t;



# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/stdio.h" 1 3 4
# 86 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 2 3 4
# 187 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
char * ctermid (char *);




FILE * tmpfile (void);
char * tmpnam (char *);

char * tempnam (const char *, const char *) __attribute__((__malloc__)) __attribute__((__warn_unused_result__));

int fclose (FILE *);
int fflush (FILE *);
FILE * freopen (const char *restrict, const char *restrict, FILE *restrict);
void setbuf (FILE *restrict, char *restrict);
int setvbuf (FILE *restrict, char *restrict, int, size_t);
int fprintf (FILE *restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 2, 3)));
int fscanf (FILE *restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__scanf__, 2, 3)));
int printf (const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 1, 2)));
int scanf (const char *restrict, ...)
               __attribute__ ((__format__ (__scanf__, 1, 2)));
int sscanf (const char *restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__scanf__, 2, 3)));
int vfprintf (FILE *restrict, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 2, 0)));
int vprintf (const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 1, 0)));
int vsprintf (char *restrict, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 2, 0)));
int fgetc (FILE *);
char * fgets (char *restrict, int, FILE *restrict);
int fputc (int, FILE *);
int fputs (const char *restrict, FILE *restrict);
int getc (FILE *);
int getchar (void);
char * gets (char *);
int putc (int, FILE *);
int putchar (int);
int puts (const char *);
int ungetc (int, FILE *);
size_t fread (void *restrict, size_t _size, size_t _n, FILE *restrict);
size_t fwrite (const void *restrict , size_t _size, size_t _n, FILE *);



int fgetpos (FILE *restrict, fpos_t *restrict);

int fseek (FILE *, long, int);



int fsetpos (FILE *, const fpos_t *);

long ftell ( FILE *);
void rewind (FILE *);
void clearerr (FILE *);
int feof (FILE *);
int ferror (FILE *);
void perror (const char *);

FILE * fopen (const char *restrict _name, const char *restrict _type);
int sprintf (char *restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 2, 3)));
int remove (const char *);
int rename (const char *, const char *);
# 263 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
int fseeko (FILE *, off_t, int);
off_t ftello (FILE *);







int snprintf (char *restrict, size_t, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
int vsnprintf (char *restrict, size_t, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
int vfscanf (FILE *restrict, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 2, 0)));
int vscanf (const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 1, 0)));
int vsscanf (const char *restrict, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 2, 0)));
# 290 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
int asiprintf (char **, const char *, ...)
               __attribute__ ((__format__ (__printf__, 2, 3)));
char * asniprintf (char *, size_t *, const char *, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
char * asnprintf (char *restrict, size_t *restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));

int diprintf (int, const char *, ...)
               __attribute__ ((__format__ (__printf__, 2, 3)));

int fiprintf (FILE *, const char *, ...)
               __attribute__ ((__format__ (__printf__, 2, 3)));
int fiscanf (FILE *, const char *, ...)
               __attribute__ ((__format__ (__scanf__, 2, 3)));
int iprintf (const char *, ...)
               __attribute__ ((__format__ (__printf__, 1, 2)));
int iscanf (const char *, ...)
               __attribute__ ((__format__ (__scanf__, 1, 2)));
int siprintf (char *, const char *, ...)
               __attribute__ ((__format__ (__printf__, 2, 3)));
int siscanf (const char *, const char *, ...)
               __attribute__ ((__format__ (__scanf__, 2, 3)));
int sniprintf (char *, size_t, const char *, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
int vasiprintf (char **, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 2, 0)));
char * vasniprintf (char *, size_t *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
char * vasnprintf (char *, size_t *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
int vdiprintf (int, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 2, 0)));
int vfiprintf (FILE *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 2, 0)));
int vfiscanf (FILE *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 2, 0)));
int viprintf (const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 1, 0)));
int viscanf (const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 1, 0)));
int vsiprintf (char *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 2, 0)));
int vsiscanf (const char *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 2, 0)));
int vsniprintf (char *, size_t, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
# 345 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
FILE * fdopen (int, const char *);

int fileno (FILE *);


int pclose (FILE *);
FILE * popen (const char *, const char *);



void setbuffer (FILE *, char *, int);
int setlinebuf (FILE *);



int getw (FILE *);
int putw (int, FILE *);


int getc_unlocked (FILE *);
int getchar_unlocked (void);
void flockfile (FILE *);
int ftrylockfile (FILE *);
void funlockfile (FILE *);
int putc_unlocked (int, FILE *);
int putchar_unlocked (int);
# 380 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
int dprintf (int, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 2, 3)));

FILE * fmemopen (void *restrict, size_t, const char *restrict);


FILE * open_memstream (char **, size_t *);
int vdprintf (int, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 2, 0)));



int renameat (int, const char *, int, const char *);
# 402 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
int _asiprintf_r (struct _reent *, char **, const char *, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
char * _asniprintf_r (struct _reent *, char *, size_t *, const char *, ...)
               __attribute__ ((__format__ (__printf__, 4, 5)));
char * _asnprintf_r (struct _reent *, char *restrict, size_t *restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 4, 5)));
int _asprintf_r (struct _reent *, char **restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
int _diprintf_r (struct _reent *, int, const char *, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
int _dprintf_r (struct _reent *, int, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
int _fclose_r (struct _reent *, FILE *);
int _fcloseall_r (struct _reent *);
FILE * _fdopen_r (struct _reent *, int, const char *);
int _fflush_r (struct _reent *, FILE *);
int _fgetc_r (struct _reent *, FILE *);
int _fgetc_unlocked_r (struct _reent *, FILE *);
char * _fgets_r (struct _reent *, char *restrict, int, FILE *restrict);
char * _fgets_unlocked_r (struct _reent *, char *restrict, int, FILE *restrict);




int _fgetpos_r (struct _reent *, FILE *, fpos_t *);
int _fsetpos_r (struct _reent *, FILE *, const fpos_t *);

int _fiprintf_r (struct _reent *, FILE *, const char *, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
int _fiscanf_r (struct _reent *, FILE *, const char *, ...)
               __attribute__ ((__format__ (__scanf__, 3, 4)));
FILE * _fmemopen_r (struct _reent *, void *restrict, size_t, const char *restrict);
FILE * _fopen_r (struct _reent *, const char *restrict, const char *restrict);
FILE * _freopen_r (struct _reent *, const char *restrict, const char *restrict, FILE *restrict);
int _fprintf_r (struct _reent *, FILE *restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
int _fpurge_r (struct _reent *, FILE *);
int _fputc_r (struct _reent *, int, FILE *);
int _fputc_unlocked_r (struct _reent *, int, FILE *);
int _fputs_r (struct _reent *, const char *restrict, FILE *restrict);
int _fputs_unlocked_r (struct _reent *, const char *restrict, FILE *restrict);
size_t _fread_r (struct _reent *, void *restrict, size_t _size, size_t _n, FILE *restrict);
size_t _fread_unlocked_r (struct _reent *, void *restrict, size_t _size, size_t _n, FILE *restrict);
int _fscanf_r (struct _reent *, FILE *restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__scanf__, 3, 4)));
int _fseek_r (struct _reent *, FILE *, long, int);
int _fseeko_r (struct _reent *, FILE *, _off_t, int);
long _ftell_r (struct _reent *, FILE *);
_off_t _ftello_r (struct _reent *, FILE *);
void _rewind_r (struct _reent *, FILE *);
size_t _fwrite_r (struct _reent *, const void *restrict, size_t _size, size_t _n, FILE *restrict);
size_t _fwrite_unlocked_r (struct _reent *, const void *restrict, size_t _size, size_t _n, FILE *restrict);
int _getc_r (struct _reent *, FILE *);
int _getc_unlocked_r (struct _reent *, FILE *);
int _getchar_r (struct _reent *);
int _getchar_unlocked_r (struct _reent *);
char * _gets_r (struct _reent *, char *);
int _iprintf_r (struct _reent *, const char *, ...)
               __attribute__ ((__format__ (__printf__, 2, 3)));
int _iscanf_r (struct _reent *, const char *, ...)
               __attribute__ ((__format__ (__scanf__, 2, 3)));
FILE * _open_memstream_r (struct _reent *, char **, size_t *);
void _perror_r (struct _reent *, const char *);
int _printf_r (struct _reent *, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 2, 3)));
int _putc_r (struct _reent *, int, FILE *);
int _putc_unlocked_r (struct _reent *, int, FILE *);
int _putchar_unlocked_r (struct _reent *, int);
int _putchar_r (struct _reent *, int);
int _puts_r (struct _reent *, const char *);
int _remove_r (struct _reent *, const char *);
int _rename_r (struct _reent *,
      const char *_old, const char *_new);
int _scanf_r (struct _reent *, const char *restrict, ...)
               __attribute__ ((__format__ (__scanf__, 2, 3)));
int _siprintf_r (struct _reent *, char *, const char *, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
int _siscanf_r (struct _reent *, const char *, const char *, ...)
               __attribute__ ((__format__ (__scanf__, 3, 4)));
int _sniprintf_r (struct _reent *, char *, size_t, const char *, ...)
               __attribute__ ((__format__ (__printf__, 4, 5)));
int _snprintf_r (struct _reent *, char *restrict, size_t, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 4, 5)));
int _sprintf_r (struct _reent *, char *restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__printf__, 3, 4)));
int _sscanf_r (struct _reent *, const char *restrict, const char *restrict, ...)
               __attribute__ ((__format__ (__scanf__, 3, 4)));
char * _tempnam_r (struct _reent *, const char *, const char *);
FILE * _tmpfile_r (struct _reent *);
char * _tmpnam_r (struct _reent *, char *);
int _ungetc_r (struct _reent *, int, FILE *);
int _vasiprintf_r (struct _reent *, char **, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
char * _vasniprintf_r (struct _reent*, char *, size_t *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 4, 0)));
char * _vasnprintf_r (struct _reent*, char *, size_t *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 4, 0)));
int _vasprintf_r (struct _reent *, char **, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
int _vdiprintf_r (struct _reent *, int, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
int _vdprintf_r (struct _reent *, int, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
int _vfiprintf_r (struct _reent *, FILE *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
int _vfiscanf_r (struct _reent *, FILE *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 3, 0)));
int _vfprintf_r (struct _reent *, FILE *restrict, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
int _vfscanf_r (struct _reent *, FILE *restrict, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 3, 0)));
int _viprintf_r (struct _reent *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 2, 0)));
int _viscanf_r (struct _reent *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 2, 0)));
int _vprintf_r (struct _reent *, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 2, 0)));
int _vscanf_r (struct _reent *, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 2, 0)));
int _vsiprintf_r (struct _reent *, char *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
int _vsiscanf_r (struct _reent *, const char *, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 3, 0)));
int _vsniprintf_r (struct _reent *, char *, size_t, const char *, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 4, 0)));
int _vsnprintf_r (struct _reent *, char *restrict, size_t, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 4, 0)));
int _vsprintf_r (struct _reent *, char *restrict, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__printf__, 3, 0)));
int _vsscanf_r (struct _reent *, const char *restrict, const char *restrict, __gnuc_va_list)
               __attribute__ ((__format__ (__scanf__, 3, 0)));



int fpurge (FILE *);
ssize_t __getdelim (char **, size_t *, int, FILE *);
ssize_t __getline (char **, size_t *, FILE *);


void clearerr_unlocked (FILE *);
int feof_unlocked (FILE *);
int ferror_unlocked (FILE *);
int fileno_unlocked (FILE *);
int fflush_unlocked (FILE *);
int fgetc_unlocked (FILE *);
int fputc_unlocked (int, FILE *);
size_t fread_unlocked (void *restrict, size_t _size, size_t _n, FILE *restrict);
size_t fwrite_unlocked (const void *restrict , size_t _size, size_t _n, FILE *);
# 583 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
int __srget_r (struct _reent *, FILE *);
int __swbuf_r (struct _reent *, int, FILE *);
# 607 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
FILE *funopen (const void *__cookie,
  int (*__readfn)(void *__cookie, char *__buf,
    int __n),
  int (*__writefn)(void *__cookie, const char *__buf,
     int __n),
  fpos_t (*__seekfn)(void *__cookie, fpos_t __off, int __whence),
  int (*__closefn)(void *__cookie));
FILE *_funopen_r (struct _reent *, const void *__cookie,
  int (*__readfn)(void *__cookie, char *__buf,
    int __n),
  int (*__writefn)(void *__cookie, const char *__buf,
     int __n),
  fpos_t (*__seekfn)(void *__cookie, fpos_t __off, int __whence),
  int (*__closefn)(void *__cookie));
# 691 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
static __inline__ int __sputc_r(struct _reent *_ptr, int _c, FILE *_p) {




 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf_r(_ptr, _c, _p));
}
# 745 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4
static __inline int
_getchar_unlocked(void)
{
 struct _reent *_ptr;

 _ptr = (__getreent());
 return ((--(((_ptr)->_stdin))->_r < 0 ? __srget_r(_ptr, ((_ptr)->_stdin)) : (int)(*(((_ptr)->_stdin))->_p++)));
}

static __inline int
_putchar_unlocked(int _c)
{
 struct _reent *_ptr;

 _ptr = (__getreent());
 return (__sputc_r(_ptr, _c, ((_ptr)->_stdout)));
}
# 801 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/stdio.h" 3 4

# 11 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_err.h" 2


# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_compiler.h" 1






       
# 14 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_err.h" 2






# 19 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_err.h"
typedef int esp_err_t;
# 59 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_err.h"
const char *esp_err_to_name(esp_err_t code);
# 77 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_err.h"
const char *esp_err_to_name_r(esp_err_t code, char *buf, size_t buflen);


void _esp_error_check_failed(esp_err_t rc, const char *file, int line, const char *function, const char *expression) __attribute__((__noreturn__));

void _esp_error_check_failed_without_abort(esp_err_t rc, const char *file, int line, const char *function, const char *expression);
# 13 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_attr.h" 1
# 14 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_bit_defs.h" 1






       
# 15 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_idf_version.h" 1






       
# 48 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_idf_version.h"
const char* esp_get_idf_version(void);
# 16 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h" 2
# 24 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h"
typedef enum {
    ESP_RST_UNKNOWN,
    ESP_RST_POWERON,
    ESP_RST_EXT,
    ESP_RST_SW,
    ESP_RST_PANIC,
    ESP_RST_INT_WDT,
    ESP_RST_TASK_WDT,
    ESP_RST_WDT,
    ESP_RST_DEEPSLEEP,
    ESP_RST_BROWNOUT,
    ESP_RST_SDIO,
    ESP_RST_USB,
    ESP_RST_JTAG,
    ESP_RST_EFUSE,
    ESP_RST_PWR_GLITCH,
    ESP_RST_CPU_LOCKUP,
} esp_reset_reason_t;




typedef void (*shutdown_handler_t)(void);
# 59 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h"
esp_err_t esp_register_shutdown_handler(shutdown_handler_t handle);
# 69 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h"
esp_err_t esp_unregister_shutdown_handler(shutdown_handler_t handle);
# 80 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h"
void esp_restart(void) __attribute__ ((__noreturn__));





esp_reset_reason_t esp_reset_reason(void);
# 96 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h"
uint32_t esp_get_free_heap_size(void);
# 106 "/Users/mdahal01/Documents/esp-idf/components/esp_system/include/esp_system.h"
uint32_t esp_get_free_internal_heap_size(void);






uint32_t esp_get_minimum_free_heap_size( void );






void __attribute__((__noreturn__)) esp_system_abort(const char* details);
# 11 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h" 1
# 39 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 40 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h" 2
# 63 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
# 1 "/Users/mdahal01/Documents/esp-idf/components/freertos/config/include/freertos/FreeRTOSConfig.h" 1






       
# 62 "/Users/mdahal01/Documents/esp-idf/components/freertos/config/include/freertos/FreeRTOSConfig.h"
# 1 "/Users/mdahal01/Documents/esp-idf/components/freertos/config/riscv/include/freertos/FreeRTOSConfig_arch.h" 1






       
# 63 "/Users/mdahal01/Documents/esp-idf/components/freertos/config/include/freertos/FreeRTOSConfig.h" 2
# 64 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h" 2


# 1 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/projdefs.h" 1
# 40 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/projdefs.h"
typedef void (* TaskFunction_t)( void * );
# 67 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h" 2


# 1 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/portable.h" 1
# 50 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/portable.h"
# 1 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/deprecated_definitions.h" 1
# 51 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/portable.h" 2






# 1 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 1
# 61 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h" 1





       




# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 1






       





# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/soc_caps.h" 1
# 25 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/soc_caps.h"
       
# 14 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 2




# 1 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h" 1






       




# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/assist_debug_reg.h" 1





       

# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/soc.h" 1






       



# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_assert.h" 1
# 12 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/soc.h" 2



# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/reg_base.h" 1
# 16 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/soc.h" 2
# 9 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/assist_debug_reg.h" 2
# 13 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/interrupt_reg.h" 1






# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/interrupt_matrix_reg.h" 1





       
# 8 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/interrupt_reg.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/intpri_reg.h" 1





       
# 9 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/interrupt_reg.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/plic_reg.h" 1





       
# 10 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/interrupt_reg.h" 2
# 14 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h" 2

# 1 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/csr.h" 1
# 28 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/csr.h"
       






# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 36 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/csr.h" 2

# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/param.h" 1 3 4
# 9 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/param.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/syslimits.h" 1 3 4
# 10 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/param.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/endian.h" 1 3 4





# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/_endian.h" 1 3 4
# 7 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/endian.h" 2 3 4
# 11 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/param.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/param.h" 1 3 4
# 12 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/param.h" 2 3 4
# 38 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/csr.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/encoding.h" 1
# 29 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/encoding.h"
       
# 39 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/csr.h" 2
# 16 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h" 1






       







enum intr_type {
    INTR_TYPE_LEVEL = 0,
    INTR_TYPE_EDGE
};



typedef void (*intr_handler_t)(void*);






void intr_handler_set(int rv_int_num, intr_handler_t fn, void* arg);





intr_handler_t intr_handler_get(int rv_int_num);





void *intr_handler_get_arg(int rv_int_num);
# 51 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h"
void intr_matrix_route(int periph_intr_source, int rv_int_num);
# 62 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h"
void esprv_intc_int_enable(uint32_t unmask);
# 71 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h"
void esprv_intc_int_disable(uint32_t mask);
# 84 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h"
void esprv_intc_int_set_type(int intr_num, enum intr_type type);
# 95 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h"
enum intr_type esprv_intc_int_get_type(int intr_num);






void esprv_intc_int_set_priority(int rv_int_num, int priority);
# 112 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h"
int esprv_intc_int_get_priority(int rv_int_num);







void esprv_intc_int_set_threshold(int priority_threshold);






uint32_t esprv_intc_get_interrupt_unmask(void);
# 136 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h"

# 136 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h" 3 4
_Bool 
# 136 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h"
    esprv_intc_int_is_vectored(int rv_int_num);
# 146 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h"
void esprv_intc_int_set_vectored(int rv_int_num, 
# 146 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h" 3 4
                                                _Bool 
# 146 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/interrupt.h"
                                                     vectored);
# 17 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h" 2
# 50 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
static inline __attribute__((always_inline)) void __attribute__((always_inline)) rv_utils_wait_for_intr(void)
{
    asm volatile ("wfi\n");
}





static inline __attribute__((always_inline)) void rv_utils_memory_barrier(void)
{
    asm volatile("fence iorw, iorw" : : : "memory");
}





static inline __attribute__((always_inline)) __attribute__((pure)) uint32_t rv_utils_get_core_id(void)
{

    return 0;





}

static inline __attribute__((always_inline)) void *rv_utils_get_sp(void)
{
    void *sp;
    asm volatile ("mv %0, sp;" : "=r" (sp));
    return sp;
}

static inline __attribute__((always_inline)) uint32_t __attribute__((always_inline)) rv_utils_get_cycle_count(void)
{




    return ({ unsigned long __tmp; asm volatile ("csrr %0, " "0x7e2" : "=r"(__tmp)); __tmp; });

}

static inline __attribute__((always_inline)) void __attribute__((always_inline)) rv_utils_set_cycle_count(uint32_t ccount)
{




    ({ asm volatile ("csrw " "0x7e2" ", %0" :: "rK"(ccount)); });

}
# 121 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
static inline __attribute__((always_inline)) void rv_utils_set_mtvec(uint32_t mtvec_val)
{



    mtvec_val |= 1;

    ({ asm volatile ("csrw " "mtvec" ", %0" :: "rK"(mtvec_val)); });
}
# 147 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
static inline __attribute__((always_inline)) void rv_utils_intr_enable(uint32_t intr_mask)
{

    unsigned old_mstatus = ({ unsigned long __tmp; asm volatile ("csrrc %0, " "mstatus" ", %1" : "=r"(__tmp) : "rK"(0x00000008)); __tmp; });
    esprv_intc_int_enable(intr_mask);
    ({ unsigned long __tmp; asm volatile ("csrrs %0, " "mstatus" ", %1" : "=r"(__tmp) : "rK"(old_mstatus & 0x00000008)); __tmp; });
}

static inline __attribute__((always_inline)) void rv_utils_intr_disable(uint32_t intr_mask)
{

    unsigned old_mstatus = ({ unsigned long __tmp; asm volatile ("csrrc %0, " "mstatus" ", %1" : "=r"(__tmp) : "rK"(0x00000008)); __tmp; });
    esprv_intc_int_disable(intr_mask);
    ({ unsigned long __tmp; asm volatile ("csrrs %0, " "mstatus" ", %1" : "=r"(__tmp) : "rK"(old_mstatus & 0x00000008)); __tmp; });
}
# 206 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
static inline __attribute__((always_inline)) uint32_t rv_utils_intr_get_enabled_mask(void)
{
# 217 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
    return ({ (*(volatile uint32_t *)((0x20001000 + 0x0))); });

}

static inline __attribute__((always_inline)) void rv_utils_intr_edge_ack(unsigned int intr_num)
{



    do { *(volatile uint32_t*)((0x20001000 + 0x8)) = (*(volatile uint32_t*)((0x20001000 + 0x8))) | (intr_num); } while(0);

}

static inline __attribute__((always_inline)) void rv_utils_intr_global_enable(void)
{
    ({ unsigned long __tmp; asm volatile ("csrrs %0, " "mstatus" ", %1" : "=r"(__tmp) : "rK"(0x00000008)); __tmp; });
}

static inline __attribute__((always_inline)) void rv_utils_intr_global_disable(void)
{
    ({ unsigned long __tmp; asm volatile ("csrrc %0, " "mstatus" ", %1" : "=r"(__tmp) : "rK"(0x00000008)); __tmp; });
}
# 281 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
static inline __attribute__((always_inline)) void rv_utils_set_breakpoint(int bp_num, uint32_t bp_addr)
{


    ({ asm volatile ("csrw " "tselect" ", %0" :: "rK"(bp_num)); });
    ({ asm volatile ("csrw " "tcontrol" ", %0" :: "rK"((1<<7) | (1<<3))); });
    ({ asm volatile ("csrw " "tdata1" ", %0" :: "rK"((1<<3) | (1<<6) | (1<<2))); });
    ({ asm volatile ("csrw " "tdata2" ", %0" :: "rK"(bp_addr)); });
}

static inline __attribute__((always_inline)) void rv_utils_set_watchpoint(int wp_num,
                                               uint32_t wp_addr,
                                               size_t size,
                                               
# 294 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h" 3 4
                                              _Bool 
# 294 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
                                                   on_read,
                                               
# 295 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h" 3 4
                                              _Bool 
# 295 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
                                                   on_write)
{
    ({ asm volatile ("csrw " "tselect" ", %0" :: "rK"(wp_num)); });
    ({ asm volatile ("csrw " "tcontrol" ", %0" :: "rK"((1<<7) | (1<<3))); });
    ({ asm volatile ("csrw " "tdata1" ", %0" :: "rK"((1<<3) | (1<<6) | ((size == 1) ? (0) : (1<<7)) | (on_read ? (1<<0) : 0) | (on_write ? (1<<1) : 0))); })



                                                       ;
# 324 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
    uint32_t match_pattern = (wp_addr & ~(size-1)) | ((size-1) >> 1);

    ({ asm volatile ("csrw " "tdata2" ", %0" :: "rK"(match_pattern)); });
}

static inline __attribute__((always_inline)) void rv_utils_clear_breakpoint(int bp_num)
{
    ({ asm volatile ("csrw " "tselect" ", %0" :: "rK"(bp_num)); });



    ({ asm volatile ("csrw " "tdata1" ", %0" :: "rK"(0)); });
}

static inline __attribute__((always_inline)) void rv_utils_clear_watchpoint(int wp_num)
{

    rv_utils_clear_breakpoint(wp_num);
}

static inline __attribute__((always_inline)) 
# 344 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h" 3 4
                 _Bool 
# 344 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
                      rv_utils_is_trigger_fired(int id)
{
    ({ asm volatile ("csrw " "tselect" ", %0" :: "rK"(id)); });
    return (({ unsigned long __tmp; asm volatile ("csrr %0, " "tdata1" : "=r"(__tmp)); __tmp; }) >> (20)) & 1;
}



static inline __attribute__((always_inline)) 
# 352 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h" 3 4
                 _Bool 
# 352 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
                      rv_utils_dbgr_is_attached(void)
{
    return ({ (*(volatile uint32_t*)((0x600C2000 + 0x74)) & (((1UL << (1))))); });
}

static inline __attribute__((always_inline)) void rv_utils_dbgr_break(void)
{
    asm volatile("ebreak\n");
}





static inline __attribute__((always_inline)) 
# 366 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h" 3 4
                 _Bool 
# 366 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
                      rv_utils_compare_and_set(volatile uint32_t *addr, uint32_t compare_value, uint32_t new_value)
{

    uint32_t old_value = 0;
    int error = 0;


    __asm__ __volatile__(
        "cas: lr.w %0, 0(%2)     \n"
        "     bne  %0, %3, fail  \n"
        "     sc.w %1, %4, 0(%2) \n"
        "     bnez %1, cas       \n"
        "fail:                   \n"
        : "+r" (old_value), "+r" (error)
        : "r" (addr), "r" (compare_value), "r" (new_value)
    );
# 396 "/Users/mdahal01/Documents/esp-idf/components/riscv/include/riscv/rv_utils.h"
    return (old_value == compare_value);
}
# 19 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 2

# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h" 1






       





# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_types.h" 1





       






typedef void (*intr_handler_t)(void *arg);


typedef struct intr_handle_data_t *intr_handle_t;






typedef enum {
    ESP_INTR_CPU_AFFINITY_AUTO,
    ESP_INTR_CPU_AFFINITY_0,
    ESP_INTR_CPU_AFFINITY_1,
} esp_intr_cpu_affinity_t;
# 14 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h" 2
# 98 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
esp_err_t esp_intr_mark_shared(int intno, int cpu, 
# 98 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h" 3 4
                                                  _Bool 
# 98 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
                                                       is_in_iram);
# 112 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
esp_err_t esp_intr_reserve(int intno, int cpu);
# 147 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
esp_err_t esp_intr_alloc(int source, int flags, intr_handler_t handler, void *arg, intr_handle_t *ret_handle);
# 185 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
esp_err_t esp_intr_alloc_intrstatus(int source, int flags, uint32_t intrstatusreg, uint32_t intrstatusmask, intr_handler_t handler, void *arg, intr_handle_t *ret_handle);
# 206 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
esp_err_t esp_intr_free(intr_handle_t handle);
# 216 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
int esp_intr_get_cpu(intr_handle_t handle);
# 225 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
int esp_intr_get_intno(intr_handle_t handle);
# 243 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
esp_err_t esp_intr_disable(intr_handle_t handle);
# 256 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
esp_err_t esp_intr_enable(intr_handle_t handle);
# 270 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
esp_err_t esp_intr_set_in_iram(intr_handle_t handle, 
# 270 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h" 3 4
                                                    _Bool 
# 270 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_intr_alloc.h"
                                                         is_in_iram);




void esp_intr_noniram_disable(void);




void esp_intr_noniram_enable(void);





void esp_intr_enable_source(int inum);





void esp_intr_disable_source(int inum);





static inline int esp_intr_flags_to_level(int flags)
{
    return __builtin_ffs((flags & ((1<<1)|(1<<2)|(1<<3)| (1<<4)|(1<<5)|(1<<6)| (1<<7))) >> 1);
}





static inline int esp_intr_level_to_flags(int level)
{
    return (level > 0) ? (1 << level) & ((1<<1)|(1<<2)|(1<<3)| (1<<4)|(1<<5)|(1<<6)| (1<<7)) : 0;
}






esp_err_t esp_intr_dump(FILE *stream);
# 21 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 2
# 33 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
typedef uint32_t esp_cpu_cycle_count_t;




typedef enum {
    ESP_CPU_INTR_TYPE_LEVEL = 0,
    ESP_CPU_INTR_TYPE_EDGE,
    ESP_CPU_INTR_TYPE_NA,
} esp_cpu_intr_type_t;
# 51 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
typedef struct {
    int priority;
    esp_cpu_intr_type_t type;
    uint32_t flags;
} esp_cpu_intr_desc_t;
# 66 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
typedef void (*esp_cpu_intr_handler_t)(void *arg);




typedef enum {
    ESP_CPU_WATCHPOINT_LOAD,
    ESP_CPU_WATCHPOINT_STORE,
    ESP_CPU_WATCHPOINT_ACCESS,
} esp_cpu_watchpoint_trigger_t;
# 86 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
void esp_cpu_stall(int core_id);






void esp_cpu_unstall(int core_id);






void esp_cpu_reset(int core_id);
# 109 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
void esp_cpu_wait_for_intr(void);
# 123 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) __attribute__((pure)) int esp_cpu_get_core_id(void)
{




    return (int)rv_utils_get_core_id();

}






static inline __attribute__((always_inline)) void *esp_cpu_get_sp(void)
{



    return rv_utils_get_sp();

}
# 155 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) esp_cpu_cycle_count_t esp_cpu_get_cycle_count(void)
{



    return (esp_cpu_cycle_count_t)rv_utils_get_cycle_count();

}
# 172 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) void esp_cpu_set_cycle_count(esp_cpu_cycle_count_t cycle_count)
{



    rv_utils_set_cycle_count((uint32_t)cycle_count);

}
# 191 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) __attribute__((pure)) void *esp_cpu_pc_to_addr(uint32_t pc)
{




    return (void *)pc;

}
# 218 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
void esp_cpu_intr_get_desc(int core_id, int intr_num, esp_cpu_intr_desc_t *intr_desc_ret);
# 227 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) void esp_cpu_intr_set_ivt_addr(const void *ivt_addr)
{



    rv_utils_set_mtvec((uint32_t)ivt_addr);

}
# 260 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) void esp_cpu_intr_set_type(int intr_num, esp_cpu_intr_type_t intr_type)
{
    
# 262 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   (__builtin_expect(!!(
# 262 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   intr_num >= 0 && intr_num < 32
# 262 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ), 1) ? (void)0 : __assert_func ((__builtin_strrchr( "/" "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h", '/') + 1), 262, __func__, 
# 262 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   "intr_num >= 0 && intr_num < SOC_CPU_INTR_NUM"
# 262 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ))
# 262 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
                                                       ;
    enum intr_type type = (intr_type == ESP_CPU_INTR_TYPE_LEVEL) ? INTR_TYPE_LEVEL : INTR_TYPE_EDGE;
    esprv_intc_int_set_type(intr_num, type);
}
# 276 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) esp_cpu_intr_type_t esp_cpu_intr_get_type(int intr_num)
{
    
# 278 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   (__builtin_expect(!!(
# 278 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   intr_num >= 0 && intr_num < 32
# 278 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ), 1) ? (void)0 : __assert_func ((__builtin_strrchr( "/" "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h", '/') + 1), 278, __func__, 
# 278 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   "intr_num >= 0 && intr_num < SOC_CPU_INTR_NUM"
# 278 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ))
# 278 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
                                                       ;
    enum intr_type type = esprv_intc_int_get_type(intr_num);
    return (type == INTR_TYPE_LEVEL) ? ESP_CPU_INTR_TYPE_LEVEL : ESP_CPU_INTR_TYPE_EDGE;
}
# 291 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) void esp_cpu_intr_set_priority(int intr_num, int intr_priority)
{
    
# 293 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   (__builtin_expect(!!(
# 293 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   intr_num >= 0 && intr_num < 32
# 293 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ), 1) ? (void)0 : __assert_func ((__builtin_strrchr( "/" "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h", '/') + 1), 293, __func__, 
# 293 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   "intr_num >= 0 && intr_num < SOC_CPU_INTR_NUM"
# 293 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ))
# 293 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
                                                       ;
    esprv_intc_int_set_priority(intr_num, intr_priority);
}
# 306 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) int esp_cpu_intr_get_priority(int intr_num)
{
    
# 308 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   (__builtin_expect(!!(
# 308 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   intr_num >= 0 && intr_num < 32
# 308 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ), 1) ? (void)0 : __assert_func ((__builtin_strrchr( "/" "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h", '/') + 1), 308, __func__, 
# 308 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   "intr_num >= 0 && intr_num < SOC_CPU_INTR_NUM"
# 308 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ))
# 308 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
                                                       ;
    return esprv_intc_int_get_priority(intr_num);
}
# 324 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) 
# 324 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
                 _Bool 
# 324 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
                      esp_cpu_intr_has_handler(int intr_num)
{
    
# 326 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   (__builtin_expect(!!(
# 326 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   intr_num >= 0 && intr_num < 32
# 326 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ), 1) ? (void)0 : __assert_func ((__builtin_strrchr( "/" "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h", '/') + 1), 326, __func__, 
# 326 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   "intr_num >= 0 && intr_num < SOC_CPU_INTR_NUM"
# 326 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ))
# 326 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
                                                       ;
    
# 327 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   _Bool 
# 327 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
        has_handler;



    has_handler = intr_handler_get(intr_num);

    return has_handler;
}
# 348 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) void esp_cpu_intr_set_handler(int intr_num, esp_cpu_intr_handler_t handler, void *handler_arg)
{
    
# 350 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   (__builtin_expect(!!(
# 350 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   intr_num >= 0 && intr_num < 32
# 350 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ), 1) ? (void)0 : __assert_func ((__builtin_strrchr( "/" "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h", '/') + 1), 350, __func__, 
# 350 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   "intr_num >= 0 && intr_num < SOC_CPU_INTR_NUM"
# 350 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ))
# 350 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
                                                       ;



    intr_handler_set(intr_num, (intr_handler_t)handler, handler_arg);

}
# 366 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) void *esp_cpu_intr_get_handler_arg(int intr_num)
{
    
# 368 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   (__builtin_expect(!!(
# 368 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   intr_num >= 0 && intr_num < 32
# 368 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ), 1) ? (void)0 : __assert_func ((__builtin_strrchr( "/" "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h", '/') + 1), 368, __func__, 
# 368 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   "intr_num >= 0 && intr_num < SOC_CPU_INTR_NUM"
# 368 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ))
# 368 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
                                                       ;
    void *handler_arg;



    handler_arg = intr_handler_get_arg(intr_num);

    return handler_arg;
}
# 385 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) void esp_cpu_intr_enable(uint32_t intr_mask)
{



    rv_utils_intr_enable(intr_mask);

}






static inline __attribute__((always_inline)) void esp_cpu_intr_disable(uint32_t intr_mask)
{



    rv_utils_intr_disable(intr_mask);

}






static inline __attribute__((always_inline)) uint32_t esp_cpu_intr_get_enabled_mask(void)
{



    return rv_utils_intr_get_enabled_mask();

}






static inline __attribute__((always_inline)) void esp_cpu_intr_edge_ack(int intr_num)
{
    
# 429 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   (__builtin_expect(!!(
# 429 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   intr_num >= 0 && intr_num < 32
# 429 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ), 1) ? (void)0 : __assert_func ((__builtin_strrchr( "/" "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h", '/') + 1), 429, __func__, 
# 429 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
   "intr_num >= 0 && intr_num < SOC_CPU_INTR_NUM"
# 429 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
   ))
# 429 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
                                                       ;



    rv_utils_intr_edge_ack((unsigned) intr_num);

}
# 444 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
void esp_cpu_configure_region_protection(void);
# 464 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
esp_err_t esp_cpu_set_breakpoint(int bp_num, const void *bp_addr);
# 473 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
esp_err_t esp_cpu_clear_breakpoint(int bp_num);
# 497 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
esp_err_t esp_cpu_set_watchpoint(int wp_num, const void *wp_addr, size_t size, esp_cpu_watchpoint_trigger_t trigger);
# 506 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
esp_err_t esp_cpu_clear_watchpoint(int wp_num);
# 515 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) 
# 515 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
                 _Bool 
# 515 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
                      esp_cpu_dbgr_is_attached(void)
{



    return rv_utils_dbgr_is_attached();

}




static inline __attribute__((always_inline)) void esp_cpu_dbgr_break(void)
{



    rv_utils_dbgr_break();

}
# 545 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
static inline __attribute__((always_inline)) intptr_t esp_cpu_get_call_addr(intptr_t return_address)
{
# 555 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
    return return_address - 4;

}
# 571 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"

# 571 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h" 3 4
_Bool 
# 571 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_cpu.h"
    esp_cpu_compare_and_set(volatile uint32_t *addr, uint32_t compare_value, uint32_t new_value);
# 12 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h" 2
# 42 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h"
typedef struct {
    uint32_t owner;
    uint32_t count;
} spinlock_t;





static inline void __attribute__((always_inline)) spinlock_initialize(spinlock_t *lock)
{
    
# 53 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h" 3 4
   (__builtin_expect(!!(
# 53 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h"
   lock
# 53 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h" 3 4
   ), 1) ? (void)0 : __assert_func ((__builtin_strrchr( "/" "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h", '/') + 1), 53, __func__, 
# 53 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h"
   "lock"
# 53 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h" 3 4
   ))
# 53 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h"
               ;




}
# 74 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h"
static inline 
# 74 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h" 3 4
             _Bool 
# 74 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h"
                  __attribute__((always_inline)) spinlock_acquire(spinlock_t *lock, int32_t timeout)
{
# 155 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h"
    return 
# 155 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h" 3 4
          1
# 155 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h"
              ;

}
# 172 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h"
static inline void __attribute__((always_inline)) spinlock_release(spinlock_t *lock)
{
# 202 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/spinlock.h"
}
# 62 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/interrupt_reg.h" 1
# 63 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_macros.h" 1






       





# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_assert.h" 1
# 14 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_macros.h" 2
# 91 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_macros.h"

# 91 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_macros.h" 3 4
_Static_assert
# 91 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_macros.h"
                (2 == 2, "CHOOSE_MACRO_VA_ARG() result does not match for 0 arguments");

# 92 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_macros.h" 3 4
_Static_assert
# 92 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_macros.h"
                (1 == 1, "CHOOSE_MACRO_VA_ARG() result does not match for 1 argument");
# 64 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 2


# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_rom/include/esp_rom_sys.h" 1






       


# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/reset_reasons.h" 1






       
# 30 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/reset_reasons.h"
typedef enum {
    RESET_REASON_CHIP_POWER_ON = 0x01,
    RESET_REASON_CHIP_BROWN_OUT = 0x01,
    RESET_REASON_CORE_SW = 0x03,
    RESET_REASON_CORE_DEEP_SLEEP = 0x05,
    RESET_REASON_CORE_SDIO = 0x06,
    RESET_REASON_CORE_MWDT0 = 0x07,
    RESET_REASON_CORE_MWDT1 = 0x08,
    RESET_REASON_CORE_RTC_WDT = 0x09,
    RESET_REASON_CPU0_MWDT0 = 0x0B,
    RESET_REASON_CPU0_SW = 0x0C,
    RESET_REASON_CPU0_RTC_WDT = 0x0D,
    RESET_REASON_SYS_BROWN_OUT = 0x0F,
    RESET_REASON_SYS_RTC_WDT = 0x10,
    RESET_REASON_CPU0_MWDT1 = 0x11,
    RESET_REASON_SYS_SUPER_WDT = 0x12,
    RESET_REASON_CORE_EFUSE_CRC = 0x14,
    RESET_REASON_CORE_USB_UART = 0x15,
    RESET_REASON_CORE_USB_JTAG = 0x16,
    RESET_REASON_CPU0_JTAG = 0x18,
} soc_reset_reason_t;
# 11 "/Users/mdahal01/Documents/esp-idf/components/esp_rom/include/esp_rom_sys.h" 2
# 22 "/Users/mdahal01/Documents/esp-idf/components/esp_rom/include/esp_rom_sys.h"
void esp_rom_software_reset_system(void);
# 32 "/Users/mdahal01/Documents/esp-idf/components/esp_rom/include/esp_rom_sys.h"
void esp_rom_software_reset_cpu(int cpu_no);
# 42 "/Users/mdahal01/Documents/esp-idf/components/esp_rom/include/esp_rom_sys.h"
int esp_rom_printf(const char *fmt, ...);






void esp_rom_delay_us(uint32_t us);
# 58 "/Users/mdahal01/Documents/esp-idf/components/esp_rom/include/esp_rom_sys.h"
void esp_rom_install_channel_putc(int channel, void (*putc)(char c));




void esp_rom_install_uart_printf(void);







soc_reset_reason_t esp_rom_get_reset_reason(int cpu_no);
# 88 "/Users/mdahal01/Documents/esp-idf/components/esp_rom/include/esp_rom_sys.h"
void esp_rom_route_intr_matrix(int cpu_core, uint32_t periph_intr_id, uint32_t cpu_intr_num);






uint32_t esp_rom_get_cpu_ticks_per_us(void);
# 104 "/Users/mdahal01/Documents/esp-idf/components/esp_rom/include/esp_rom_sys.h"
void esp_rom_set_cpu_ticks_per_us(uint32_t ticks_per_us);
# 67 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h" 1






       



# 1 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h" 1





       
# 22 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
typedef struct multi_heap_info *multi_heap_handle_t;
# 33 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
void *multi_heap_aligned_alloc(multi_heap_handle_t heap, size_t size, size_t alignment);
# 44 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
void *multi_heap_malloc(multi_heap_handle_t heap, size_t size);







void __attribute__((deprecated)) multi_heap_aligned_free(multi_heap_handle_t heap, void *p);
# 61 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
void multi_heap_free(multi_heap_handle_t heap, void *p);
# 73 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
void *multi_heap_realloc(multi_heap_handle_t heap, void *p, size_t size);
# 84 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
size_t multi_heap_get_allocated_size(multi_heap_handle_t heap, void *p);
# 98 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
multi_heap_handle_t multi_heap_register(void *start, size_t size);
# 112 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
void multi_heap_set_lock(multi_heap_handle_t heap, void* lock);







void multi_heap_dump(multi_heap_handle_t heap);
# 134 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"

# 134 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h" 3 4
_Bool 
# 134 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
    multi_heap_check(multi_heap_handle_t heap, 
# 134 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h" 3 4
                                               _Bool 
# 134 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
                                                    print_errors);
# 148 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
size_t multi_heap_free_size(multi_heap_handle_t heap);
# 160 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
size_t multi_heap_minimum_free_size(multi_heap_handle_t heap);


typedef struct {
    size_t total_free_bytes;
    size_t total_allocated_bytes;
    size_t largest_free_block;
    size_t minimum_free_bytes;
    size_t allocated_blocks;
    size_t free_blocks;
    size_t total_blocks;
} multi_heap_info_t;
# 180 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
void multi_heap_get_info(multi_heap_handle_t heap, multi_heap_info_t *info);
# 191 "/Users/mdahal01/Documents/esp-idf/components/heap/include/multi_heap.h"
void *multi_heap_aligned_alloc_offs(multi_heap_handle_t heap, size_t size, size_t alignment, size_t offset);
# 12 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h" 2
# 55 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
typedef void (*esp_alloc_failed_hook_t) (size_t size, uint32_t caps, const char * function_name);






esp_err_t heap_caps_register_failed_alloc_callback(esp_alloc_failed_hook_t callback);
# 95 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void *heap_caps_malloc(size_t size, uint32_t caps);
# 107 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void heap_caps_free( void *ptr);
# 126 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void *heap_caps_realloc( void *ptr, size_t size, uint32_t caps);
# 142 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void *heap_caps_aligned_alloc(size_t alignment, size_t size, uint32_t caps);







void __attribute__((deprecated)) heap_caps_aligned_free(void *ptr);
# 165 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void *heap_caps_aligned_calloc(size_t alignment, size_t n, size_t size, uint32_t caps);
# 182 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void *heap_caps_calloc(size_t n, size_t size, uint32_t caps);
# 196 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
size_t heap_caps_get_total_size(uint32_t caps);
# 212 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
size_t heap_caps_get_free_size( uint32_t caps );
# 230 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
size_t heap_caps_get_minimum_free_size( uint32_t caps );
# 242 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
size_t heap_caps_get_largest_free_block( uint32_t caps );
# 258 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void heap_caps_get_info( multi_heap_info_t *info, uint32_t caps );
# 271 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void heap_caps_print_heap_info( uint32_t caps );
# 288 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"

# 288 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h" 3 4
_Bool 
# 288 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
    heap_caps_check_integrity_all(
# 288 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h" 3 4
                                  _Bool 
# 288 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
                                       print_errors);
# 309 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"

# 309 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h" 3 4
_Bool 
# 309 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
    heap_caps_check_integrity(uint32_t caps, 
# 309 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h" 3 4
                                             _Bool 
# 309 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
                                                  print_errors);
# 332 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"

# 332 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h" 3 4
_Bool 
# 332 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
    heap_caps_check_integrity_addr(intptr_t addr, 
# 332 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h" 3 4
                                                  _Bool 
# 332 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
                                                       print_errors);
# 345 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void heap_caps_malloc_extmem_enable(size_t limit);
# 360 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void *heap_caps_malloc_prefer( size_t size, size_t num, ... );
# 371 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void *heap_caps_realloc_prefer( void *ptr, size_t size, size_t num, ... );
# 382 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void *heap_caps_calloc_prefer( size_t n, size_t size, size_t num, ... );
# 401 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void heap_caps_dump(uint32_t caps);
# 411 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
void heap_caps_dump_all(void);
# 424 "/Users/mdahal01/Documents/esp-idf/components/heap/include/esp_heap_caps.h"
size_t heap_caps_get_allocated_size( void *ptr );
# 68 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 2

# 1 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/esp_newlib.h" 1






       
# 18 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/esp_newlib.h"
void esp_newlib_time_init(void);







void esp_reent_init(struct _reent* r);
# 37 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/esp_newlib.h"
void esp_newlib_init_global_stdio(const char* stdio_dev);




void esp_reent_cleanup(void);
# 52 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/esp_newlib.h"
void esp_newlib_init(void);

void esp_setup_syscall_table(void) __attribute__((deprecated("Please call esp_newlib_init() in newer code")));




void esp_set_time_from_rtc(void);




void esp_sync_timekeeping_timers(void);







void esp_newlib_locks_init(void);
# 70 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 2


# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/limits.h" 1 3 4
# 34 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/limits.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/syslimits.h" 1 3 4






# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/limits.h" 1 3 4
# 205 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/limits.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/limits.h" 1 3 4
# 206 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/limits.h" 2 3 4
# 8 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/syslimits.h" 2 3 4
# 35 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/limits.h" 2 3 4
# 73 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 2
# 98 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
typedef uint8_t StackType_t;
typedef int BaseType_t;
typedef unsigned int UBaseType_t;





typedef uint32_t TickType_t;
# 142 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
UBaseType_t xPortSetInterruptMaskFromISR(void);







void vPortClearInterruptMaskFromISR(UBaseType_t prev_int_level);
# 163 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
BaseType_t xPortInIsrContext(void);
# 176 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
BaseType_t xPortInterruptedFromISRContext(void);
# 187 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
typedef spinlock_t portMUX_TYPE;
# 216 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
void vPortEnterCritical(void);







void vPortExitCritical(void);
# 348 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
int vPortSetInterruptMask(void);






void vPortClearInterruptMask(int mask);






void vPortYield(void);




void vPortYieldFromISR(void);
# 376 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
void vPortYieldOtherCore(BaseType_t coreid);
# 388 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
static inline __attribute__((always_inline)) 
# 388 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 3 4
                 _Bool 
# 388 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
                      xPortCanYield(void);
# 399 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
void vApplicationSleep(TickType_t xExpectedIdleTime);
# 410 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
uint32_t xPortGetTickRateHz(void);
# 420 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
void vPortSetStackWatchpoint(void *pxStackStart);
# 429 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
static inline __attribute__((always_inline)) BaseType_t xPortGetCoreID(void)
{
    return (BaseType_t) esp_cpu_get_core_id();
}
# 446 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
void vPortTCBPreDeleteHook( void *pxTCB );
# 663 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
static inline __attribute__((always_inline)) 
# 663 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 3 4
                 _Bool 
# 663 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
                      xPortCanYield(void)
{
    uint32_t threshold = ({ (*(volatile uint32_t *)((0x20001000 + 0x90))); });
# 684 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
    return (threshold <= 1);
}
# 705 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"

# 705 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 3 4
_Bool 
# 705 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
    xPortCheckValidListMem(const void *ptr);
# 716 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"

# 716 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 3 4
_Bool 
# 716 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
    xPortCheckValidTCBMem(const void *ptr);
# 727 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"

# 727 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h" 3 4
_Bool 
# 727 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/portable/riscv/include/freertos/portmacro.h"
    xPortcheckValidStackMem(const void *ptr);
# 58 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/portable.h" 2
# 103 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/portable.h"
# 1 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/mpu_wrappers.h" 1
# 104 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/portable.h" 2
# 131 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/portable.h"
        StackType_t * pxPortInitialiseStack( StackType_t * pxTopOfStack,
                                             TaskFunction_t pxCode,
                                             void * pvParameters ) ;





typedef struct HeapRegion
{
    uint8_t * pucStartAddress;
    size_t xSizeInBytes;
} HeapRegion_t;


typedef struct xHeapStats
{
    size_t xAvailableHeapSpaceInBytes;
    size_t xSizeOfLargestFreeBlockInBytes;
    size_t xSizeOfSmallestFreeBlockInBytes;
    size_t xNumberOfFreeBlocks;
    size_t xMinimumEverFreeBytesRemaining;
    size_t xNumberOfSuccessfulAllocations;
    size_t xNumberOfSuccessfulFrees;
} HeapStats_t;
# 168 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/portable.h"
void vPortDefineHeapRegions( const HeapRegion_t * const pxHeapRegions ) ;





void vPortGetHeapStats( HeapStats_t * pxHeapStats );




void * pvPortMalloc( size_t xSize ) ;
void * pvPortCalloc( size_t xNum,
                     size_t xSize ) ;
void vPortFree( void * pv ) ;
void vPortInitialiseBlocks( void ) ;
size_t xPortGetFreeHeapSize( void ) ;
size_t xPortGetMinimumEverFreeHeapSize( void ) ;
# 212 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/portable.h"
BaseType_t xPortStartScheduler( void ) ;






void vPortEndScheduler( void ) ;
# 70 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h" 2
# 88 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/reent.h" 1 3 4
# 98 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/reent.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 99 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/reent.h" 2 3 4



# 101 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/reent.h" 3 4
struct stat;
struct tms;
struct timeval;
struct timezone;
# 140 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/reent.h" 3 4
extern int _close_r (struct _reent *, int);
extern int _execve_r (struct _reent *, const char *, char *const *, char *const *);
extern int _fcntl_r (struct _reent *, int, int, int);
extern int _fork_r (struct _reent *);
extern int _fstat_r (struct _reent *, int, struct stat *);
extern int _getpid_r (struct _reent *);
extern int _isatty_r (struct _reent *, int);
extern int _kill_r (struct _reent *, int, int);
extern int _link_r (struct _reent *, const char *, const char *);
extern _off_t _lseek_r (struct _reent *, int, _off_t, int);
extern int _mkdir_r (struct _reent *, const char *, int);
extern int _open_r (struct _reent *, const char *, int, int);
extern _ssize_t _read_r (struct _reent *, int, void *, size_t);
extern int _rename_r (struct _reent *, const char *, const char *);
extern void *_sbrk_r (struct _reent *, ptrdiff_t);
extern int _stat_r (struct _reent *, const char *, struct stat *);
extern unsigned long _times_r (struct _reent *, struct tms *);
extern int _unlink_r (struct _reent *, const char *);
extern int _wait_r (struct _reent *, int *);
extern _ssize_t _write_r (struct _reent *, int, const void *, size_t);
extern int _getentropy_r (struct _reent *, void *, size_t);


extern int _gettimeofday_r (struct _reent *, struct timeval *__tp, void *__tzp);
# 89 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h" 2
# 1227 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"

# 1227 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
struct xSTATIC_LIST_ITEM
{



    TickType_t xDummy2;
    void * pvDummy3[ 4 ];



};
typedef struct xSTATIC_LIST_ITEM StaticListItem_t;



    struct xSTATIC_MINI_LIST_ITEM
    {



        TickType_t xDummy2;
        void * pvDummy3[ 2 ];
    };
    typedef struct xSTATIC_MINI_LIST_ITEM StaticMiniListItem_t;





typedef struct xSTATIC_LIST
{



    UBaseType_t uxDummy2;
    void * pvDummy3;
    StaticMiniListItem_t xDummy4;



} StaticList_t;
# 1282 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
typedef struct xSTATIC_TCB
{
    void * pxDummy1;



    StaticListItem_t xDummy3[ 2 ];
    UBaseType_t uxDummy5;
    void * pxDummy6;
    uint8_t ucDummy7[ 
# 1291 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h" 3 4
                     16 
# 1291 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
                                             ];




        void * pxDummy8;
# 1305 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
        UBaseType_t uxDummy12[ 2 ];





        void * pvDummy15[ ( 
# 1311 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h" 3 4
                         2 
# 1311 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
                         * 2 ) ];





        struct _reent xDummy17;


        uint32_t ulDummy18[ 
# 1320 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h" 3 4
                           1 
# 1320 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
                                                                 ];
        uint8_t ucDummy19[ 
# 1321 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h" 3 4
                          1 
# 1321 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
                                                                ];


        uint8_t uxDummy20;



        uint8_t ucDummy21;




} StaticTask_t;
# 1349 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
typedef struct xSTATIC_QUEUE
{
    void * pvDummy1[ 3 ];

    union
    {
        void * pvDummy2;
        UBaseType_t uxDummy2;
    } u;

    StaticList_t xDummy3[ 2 ];
    UBaseType_t uxDummy4[ 3 ];
    uint8_t ucDummy5[ 2 ];


        uint8_t ucDummy6;



        void * pvDummy7;






    portMUX_TYPE xDummyQueueLock;
} StaticQueue_t;
typedef StaticQueue_t StaticSemaphore_t;
# 1393 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
typedef struct xSTATIC_EVENT_GROUP
{
    TickType_t xDummy1;
    StaticList_t xDummy2;






        uint8_t ucDummy4;

    portMUX_TYPE xDummyEventGroupLock;
} StaticEventGroup_t;
# 1422 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
typedef struct xSTATIC_TIMER
{
    void * pvDummy1;
    StaticListItem_t xDummy2;
    TickType_t xDummy3;
    void * pvDummy5;
    TaskFunction_t pvDummy6;



    uint8_t ucDummy8;
} StaticTimer_t;
# 1449 "/Users/mdahal01/Documents/esp-idf/components/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h"
typedef struct xSTATIC_STREAM_BUFFER
{
    size_t uxDummy1[ 4 ];
    void * pvDummy2[ 3 ];
    uint8_t ucDummy3;






    portMUX_TYPE xDummyStreamBufferLock;
} StaticStreamBuffer_t;


typedef StaticStreamBuffer_t StaticMessageBuffer_t;
# 12 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h" 1
# 13 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
       

# 1 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/i2s_types.h" 1






       




# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 13 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/i2s_types.h" 2


# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h" 1





       
# 60 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    SOC_ROOT_CLK_INT_RC_FAST,
    SOC_ROOT_CLK_INT_RC_SLOW,
    SOC_ROOT_CLK_EXT_XTAL,
    SOC_ROOT_CLK_EXT_XTAL32K,
    SOC_ROOT_CLK_INT_RC32K,
    SOC_ROOT_CLK_EXT_OSC_SLOW,
} soc_root_clk_t;





typedef enum {
    SOC_CPU_CLK_SRC_XTAL = 0,
    SOC_CPU_CLK_SRC_PLL = 1,
    SOC_CPU_CLK_SRC_RC_FAST = 2,
    SOC_CPU_CLK_SRC_INVALID,
} soc_cpu_clk_src_t;





typedef enum {
    SOC_RTC_SLOW_CLK_SRC_RC_SLOW = 0,
    SOC_RTC_SLOW_CLK_SRC_XTAL32K = 1,
    SOC_RTC_SLOW_CLK_SRC_RC32K = 2,
    SOC_RTC_SLOW_CLK_SRC_OSC_SLOW = 3,
    SOC_RTC_SLOW_CLK_SRC_INVALID,
} soc_rtc_slow_clk_src_t;





typedef enum {
    SOC_RTC_FAST_CLK_SRC_RC_FAST = 0,
    SOC_RTC_FAST_CLK_SRC_XTAL_D2 = 1,
    SOC_RTC_FAST_CLK_SRC_XTAL_DIV = SOC_RTC_FAST_CLK_SRC_XTAL_D2,
    SOC_RTC_FAST_CLK_SRC_INVALID,
} soc_rtc_fast_clk_src_t;
# 111 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {

    SOC_MOD_CLK_CPU = 1,

    SOC_MOD_CLK_RTC_FAST,
    SOC_MOD_CLK_RTC_SLOW,

    SOC_MOD_CLK_PLL_F80M,
    SOC_MOD_CLK_PLL_F160M,
    SOC_MOD_CLK_PLL_F240M,
    SOC_MOD_CLK_XTAL32K,
    SOC_MOD_CLK_RC_FAST,
    SOC_MOD_CLK_XTAL,

    SOC_MOD_CLK_XTAL_D2,

    SOC_MOD_CLK_INVALID,
} soc_module_clk_t;






typedef enum {
    SYSTIMER_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    SYSTIMER_CLK_SRC_RC_FAST = SOC_MOD_CLK_RC_FAST,
    SYSTIMER_CLK_SRC_DEFAULT = SOC_MOD_CLK_XTAL,
} soc_periph_systimer_clk_src_t;
# 160 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    GPTIMER_CLK_SRC_PLL_F80M = SOC_MOD_CLK_PLL_F80M,
    GPTIMER_CLK_SRC_RC_FAST = SOC_MOD_CLK_RC_FAST,
    GPTIMER_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    GPTIMER_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F80M,
} soc_periph_gptimer_clk_src_t;




typedef enum {
    TIMER_SRC_CLK_PLL_F80M = SOC_MOD_CLK_PLL_F80M,
    TIMER_SRC_CLK_XTAL = SOC_MOD_CLK_XTAL,
    TIMER_SRC_CLK_DEFAULT = SOC_MOD_CLK_PLL_F80M,
} soc_periph_tg_clk_src_legacy_t;
# 186 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    RMT_CLK_SRC_PLL_F80M = SOC_MOD_CLK_PLL_F80M,
    RMT_CLK_SRC_RC_FAST = SOC_MOD_CLK_RC_FAST,
    RMT_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    RMT_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F80M,
} soc_periph_rmt_clk_src_t;




typedef enum {
    RMT_BASECLK_PLL_F80M = SOC_MOD_CLK_PLL_F80M,
    RMT_BASECLK_XTAL = SOC_MOD_CLK_XTAL,
    RMT_BASECLK_DEFAULT = SOC_MOD_CLK_PLL_F80M,
} soc_periph_rmt_clk_src_legacy_t;
# 212 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    TEMPERATURE_SENSOR_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    TEMPERATURE_SENSOR_CLK_SRC_RC_FAST = SOC_MOD_CLK_RC_FAST,
    TEMPERATURE_SENSOR_CLK_SRC_DEFAULT = SOC_MOD_CLK_XTAL,
} soc_periph_temperature_sensor_clk_src_t;
# 228 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    UART_SCLK_PLL_F80M = SOC_MOD_CLK_PLL_F80M,
    UART_SCLK_RTC = SOC_MOD_CLK_RC_FAST,
    UART_SCLK_XTAL = SOC_MOD_CLK_XTAL,
    UART_SCLK_DEFAULT = SOC_MOD_CLK_PLL_F80M,
} soc_periph_uart_clk_src_legacy_t;
# 243 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    LP_UART_SCLK_LP_FAST = SOC_MOD_CLK_RTC_FAST,
    LP_UART_SCLK_XTAL_D2 = SOC_MOD_CLK_XTAL_D2,
    LP_UART_SCLK_DEFAULT = SOC_MOD_CLK_RTC_FAST,
} soc_periph_lp_uart_clk_src_t;
# 259 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    MCPWM_TIMER_CLK_SRC_PLL160M = SOC_MOD_CLK_PLL_F160M,
    MCPWM_TIMER_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    MCPWM_TIMER_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F160M,
} soc_periph_mcpwm_timer_clk_src_t;
# 273 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    MCPWM_CAPTURE_CLK_SRC_PLL160M = SOC_MOD_CLK_PLL_F160M,
    MCPWM_CAPTURE_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    MCPWM_CAPTURE_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F160M,
} soc_periph_mcpwm_capture_clk_src_t;
# 287 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    MCPWM_CARRIER_CLK_SRC_PLL160M = SOC_MOD_CLK_PLL_F160M,
    MCPWM_CARRIER_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    MCPWM_CARRIER_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F160M,
} soc_periph_mcpwm_carrier_clk_src_t;
# 303 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    I2S_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F160M,
    I2S_CLK_SRC_PLL_160M = SOC_MOD_CLK_PLL_F160M,
    I2S_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    I2S_CLK_SRC_EXTERNAL = -1,
} soc_periph_i2s_clk_src_t;
# 320 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    I2C_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    I2C_CLK_SRC_RC_FAST = SOC_MOD_CLK_RC_FAST,
    I2C_CLK_SRC_DEFAULT = SOC_MOD_CLK_XTAL,
} soc_periph_i2c_clk_src_t;
# 336 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    LP_I2C_SCLK_LP_FAST = SOC_MOD_CLK_RTC_FAST,
    LP_I2C_SCLK_XTAL_D2 = SOC_MOD_CLK_XTAL_D2,
    LP_I2C_SCLK_DEFAULT = SOC_MOD_CLK_RTC_FAST,
} soc_periph_lp_i2c_clk_src_t;
# 352 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    SPI_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F80M,
    SPI_CLK_SRC_PLL_F80M = SOC_MOD_CLK_PLL_F80M,
    SPI_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    SPI_CLK_SRC_RC_FAST = SOC_MOD_CLK_RC_FAST,
} soc_periph_spi_clk_src_t;
# 369 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    SDM_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    SDM_CLK_SRC_PLL_F80M = SOC_MOD_CLK_PLL_F80M,
    SDM_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F80M,
} soc_periph_sdm_clk_src_t;
# 386 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    GLITCH_FILTER_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    GLITCH_FILTER_CLK_SRC_PLL_F80M = SOC_MOD_CLK_PLL_F80M,
    GLITCH_FILTER_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F80M,
} soc_periph_glitch_filter_clk_src_t;
# 402 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    TWAI_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    TWAI_CLK_SRC_DEFAULT = SOC_MOD_CLK_XTAL,
} soc_periph_twai_clk_src_t;
# 417 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    ADC_DIGI_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    ADC_DIGI_CLK_SRC_PLL_F80M = SOC_MOD_CLK_PLL_F80M,
    ADC_DIGI_CLK_SRC_RC_FAST = SOC_MOD_CLK_RC_FAST,
    ADC_DIGI_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F80M,
} soc_periph_adc_digi_clk_src_t;
# 434 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    MWDT_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    MWDT_CLK_SRC_PLL_F80M = SOC_MOD_CLK_PLL_F80M,
    MWDT_CLK_SRC_RC_FAST = SOC_MOD_CLK_RC_FAST,
    MWDT_CLK_SRC_DEFAULT = SOC_MOD_CLK_XTAL,
} soc_periph_mwdt_clk_src_t;
# 451 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    LEDC_AUTO_CLK = 0,
    LEDC_USE_PLL_DIV_CLK = SOC_MOD_CLK_PLL_F80M,
    LEDC_USE_RC_FAST_CLK = SOC_MOD_CLK_RC_FAST,
    LEDC_USE_XTAL_CLK = SOC_MOD_CLK_XTAL,

    LEDC_USE_RTC8M_CLK __attribute__((deprecated("please use 'LEDC_USE_RC_FAST_CLK' instead"))) = LEDC_USE_RC_FAST_CLK,
} soc_periph_ledc_clk_src_legacy_t;
# 470 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/clk_tree_defs.h"
typedef enum {
    PARLIO_CLK_SRC_XTAL = SOC_MOD_CLK_XTAL,
    PARLIO_CLK_SRC_PLL_F240M = SOC_MOD_CLK_PLL_F240M,
    PARLIO_CLK_SRC_DEFAULT = SOC_MOD_CLK_PLL_F240M,
} soc_periph_parlio_clk_src_t;


typedef enum {
    CLKOUT_SIG_PLL = 1,
    CLKOUT_SIG_XTAL = 5,
    CLKOUT_SIG_PLL_F80M = 13,
    CLKOUT_SIG_CPU = 16,
    CLKOUT_SIG_AHB = 17,
    CLKOUT_SIG_APB = 18,
    CLKOUT_SIG_XTAL32K = 21,
    CLKOUT_SIG_EXT32K = 22,
    CLKOUT_SIG_RC_FAST = 23,
    CLKOUT_SIG_RC_32K = 24,
    CLKOUT_SIG_RC_SLOW = 25,
    CLKOUT_SIG_INVALID = 0xFF,
} soc_clkout_sig_id_t;
# 16 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/i2s_types.h" 2
# 24 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/i2s_types.h"
typedef enum {
    I2S_SLOT_MODE_MONO = 1,
    I2S_SLOT_MODE_STEREO = 2,
} i2s_slot_mode_t;




typedef enum {
    I2S_DIR_RX = (1UL << (0)),
    I2S_DIR_TX = (1UL << (1)),
} i2s_dir_t;




typedef enum {
    I2S_ROLE_MASTER,
    I2S_ROLE_SLAVE
} i2s_role_t;




typedef enum {
    I2S_DATA_BIT_WIDTH_8BIT = 8,
    I2S_DATA_BIT_WIDTH_16BIT = 16,
    I2S_DATA_BIT_WIDTH_24BIT = 24,
    I2S_DATA_BIT_WIDTH_32BIT = 32,
} i2s_data_bit_width_t;





typedef enum {
    I2S_SLOT_BIT_WIDTH_AUTO = (0),
    I2S_SLOT_BIT_WIDTH_8BIT = (8),
    I2S_SLOT_BIT_WIDTH_16BIT = (16),
    I2S_SLOT_BIT_WIDTH_24BIT = (24),
    I2S_SLOT_BIT_WIDTH_32BIT = (32),
} i2s_slot_bit_width_t;


typedef soc_periph_i2s_clk_src_t i2s_clock_src_t;
# 79 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/i2s_types.h"
typedef enum {
    I2S_PCM_DISABLE = 0,
    I2S_PCM_A_DECOMPRESS,
    I2S_PCM_A_COMPRESS,
    I2S_PCM_U_DECOMPRESS,
    I2S_PCM_U_COMPRESS,
} i2s_pcm_compress_t;
# 103 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/i2s_types.h"
typedef enum {
    I2S_PDM_SIG_SCALING_DIV_2 = 0,
    I2S_PDM_SIG_SCALING_MUL_1 = 1,
    I2S_PDM_SIG_SCALING_MUL_2 = 2,
    I2S_PDM_SIG_SCALING_MUL_4 = 3,
} i2s_pdm_sig_scale_t;
# 117 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/i2s_types.h"
typedef enum {
    I2S_PDM_TX_ONE_LINE_CODEC,
    I2S_PDM_TX_ONE_LINE_DAC,
    I2S_PDM_TX_TWO_LINE_DAC,
} i2s_pdm_tx_line_mode_t;
# 130 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/i2s_types.h"
typedef enum {
    I2S_STD_SLOT_LEFT = (1UL << (0)),
    I2S_STD_SLOT_RIGHT = (1UL << (1)),
    I2S_STD_SLOT_BOTH = (1UL << (0)) | (1UL << (1)),
} i2s_std_slot_mask_t;





typedef enum {
    I2S_PDM_SLOT_RIGHT = (1UL << (0)),
    I2S_PDM_SLOT_LEFT = (1UL << (1)),
    I2S_PDM_SLOT_BOTH = (1UL << (0)) | (1UL << (1)),
# 156 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/i2s_types.h"
} i2s_pdm_slot_mask_t;
# 167 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/i2s_types.h"
typedef enum {
    I2S_TDM_SLOT0 = (1UL << (0)),
    I2S_TDM_SLOT1 = (1UL << (1)),
    I2S_TDM_SLOT2 = (1UL << (2)),
    I2S_TDM_SLOT3 = (1UL << (3)),
    I2S_TDM_SLOT4 = (1UL << (4)),
    I2S_TDM_SLOT5 = (1UL << (5)),
    I2S_TDM_SLOT6 = (1UL << (6)),
    I2S_TDM_SLOT7 = (1UL << (7)),
    I2S_TDM_SLOT8 = (1UL << (8)),
    I2S_TDM_SLOT9 = (1UL << (9)),
    I2S_TDM_SLOT10 = (1UL << (10)),
    I2S_TDM_SLOT11 = (1UL << (11)),
    I2S_TDM_SLOT12 = (1UL << (12)),
    I2S_TDM_SLOT13 = (1UL << (13)),
    I2S_TDM_SLOT14 = (1UL << (14)),
    I2S_TDM_SLOT15 = (1UL << (15)),
} i2s_tdm_slot_mask_t;
# 16 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/gpio_types.h" 1






       


# 1 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/gpio_num.h" 1






       
# 16 "/Users/mdahal01/Documents/esp-idf/components/soc/esp32c6/include/soc/gpio_num.h"
typedef enum {
    GPIO_NUM_NC = -1,
    GPIO_NUM_0 = 0,
    GPIO_NUM_1 = 1,
    GPIO_NUM_2 = 2,
    GPIO_NUM_3 = 3,
    GPIO_NUM_4 = 4,
    GPIO_NUM_5 = 5,
    GPIO_NUM_6 = 6,
    GPIO_NUM_7 = 7,
    GPIO_NUM_8 = 8,
    GPIO_NUM_9 = 9,
    GPIO_NUM_10 = 10,
    GPIO_NUM_11 = 11,
    GPIO_NUM_12 = 12,
    GPIO_NUM_13 = 13,
    GPIO_NUM_14 = 14,
    GPIO_NUM_15 = 15,
    GPIO_NUM_16 = 16,
    GPIO_NUM_17 = 17,
    GPIO_NUM_18 = 18,
    GPIO_NUM_19 = 19,
    GPIO_NUM_20 = 20,
    GPIO_NUM_21 = 21,
    GPIO_NUM_22 = 22,
    GPIO_NUM_23 = 23,
    GPIO_NUM_24 = 24,
    GPIO_NUM_25 = 25,
    GPIO_NUM_26 = 26,
    GPIO_NUM_27 = 27,
    GPIO_NUM_28 = 28,
    GPIO_NUM_29 = 29,
    GPIO_NUM_30 = 30,
    GPIO_NUM_MAX,
} gpio_num_t;
# 11 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/gpio_types.h" 2






typedef enum {
    GPIO_PORT_0 = 0,
    GPIO_PORT_MAX,
} gpio_port_t;
# 80 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/gpio_types.h"
typedef enum {
    GPIO_INTR_DISABLE = 0,
    GPIO_INTR_POSEDGE = 1,
    GPIO_INTR_NEGEDGE = 2,
    GPIO_INTR_ANYEDGE = 3,
    GPIO_INTR_LOW_LEVEL = 4,
    GPIO_INTR_HIGH_LEVEL = 5,
    GPIO_INTR_MAX,
} gpio_int_type_t;
# 97 "/Users/mdahal01/Documents/esp-idf/components/hal/include/hal/gpio_types.h"
typedef enum {
    GPIO_MODE_DISABLE = (0),
    GPIO_MODE_INPUT = (0x00000001),
    GPIO_MODE_OUTPUT = (0x00000002),
    GPIO_MODE_OUTPUT_OD = (((0x00000002)) | ((0x00000004))),
    GPIO_MODE_INPUT_OUTPUT_OD = (((0x00000001)) | ((0x00000002)) | ((0x00000004))),
    GPIO_MODE_INPUT_OUTPUT = (((0x00000001)) | ((0x00000002))),
} gpio_mode_t;

typedef enum {
    GPIO_PULLUP_DISABLE = 0x0,
    GPIO_PULLUP_ENABLE = 0x1,
} gpio_pullup_t;

typedef enum {
    GPIO_PULLDOWN_DISABLE = 0x0,
    GPIO_PULLDOWN_ENABLE = 0x1,
} gpio_pulldown_t;

typedef enum {
    GPIO_PULLUP_ONLY,
    GPIO_PULLDOWN_ONLY,
    GPIO_PULLUP_PULLDOWN,
    GPIO_FLOATING,
} gpio_pull_mode_t;

typedef enum {
    GPIO_DRIVE_CAP_0 = 0,
    GPIO_DRIVE_CAP_1 = 1,
    GPIO_DRIVE_CAP_2 = 2,
    GPIO_DRIVE_CAP_DEFAULT = 2,
    GPIO_DRIVE_CAP_3 = 3,
    GPIO_DRIVE_CAP_MAX,
} gpio_drive_cap_t;
# 17 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h" 1






       

# 1 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_types.h" 1






       



# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 12 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_types.h" 2
# 21 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_types.h"
typedef enum {
    I2S_NUM_0 = 0,



    I2S_NUM_AUTO,
} i2s_port_t;




typedef enum {
    I2S_COMM_MODE_STD,

    I2S_COMM_MODE_PDM,


    I2S_COMM_MODE_TDM,

    I2S_COMM_MODE_NONE,
} i2s_comm_mode_t;




typedef enum {
    I2S_MCLK_MULTIPLE_128 = 128,
    I2S_MCLK_MULTIPLE_256 = 256,
    I2S_MCLK_MULTIPLE_384 = 384,
    I2S_MCLK_MULTIPLE_512 = 512,
} i2s_mclk_multiple_t;




typedef struct {
    void *data;


    size_t size;



} i2s_event_data_t;

typedef struct i2s_channel_obj_t *i2s_chan_handle_t;
# 76 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_types.h"
typedef 
# 76 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_types.h" 3 4
       _Bool 
# 76 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_types.h"
            (*i2s_isr_callback_t)(i2s_chan_handle_t handle, i2s_event_data_t *event, void *user_ctx);
# 10 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h" 2


# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_types.h" 1
# 15 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_types.h"
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/lib/gcc/riscv32-esp-elf/13.2.0/include/stddef.h" 1 3 4
# 16 "/Users/mdahal01/Documents/esp-idf/components/esp_common/include/esp_types.h" 2
# 13 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h" 2
# 39 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
typedef struct {
    i2s_isr_callback_t on_recv;


    i2s_isr_callback_t on_recv_q_ovf;


    i2s_isr_callback_t on_sent;


    i2s_isr_callback_t on_send_q_ovf;


} i2s_event_callbacks_t;




typedef struct {
    i2s_port_t id;
    i2s_role_t role;


    uint32_t dma_desc_num;
    uint32_t dma_frame_num;


    
# 66 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h" 3 4
   _Bool 
# 66 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
                       auto_clear;
    int intr_priority;
} i2s_chan_config_t;




typedef struct {
    i2s_port_t id;
    i2s_role_t role;
    i2s_dir_t dir;
    i2s_comm_mode_t mode;
    i2s_chan_handle_t pair_chan;
} i2s_chan_info_t;
# 106 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
esp_err_t i2s_new_channel(const i2s_chan_config_t *chan_cfg, i2s_chan_handle_t *ret_tx_handle, i2s_chan_handle_t *ret_rx_handle);
# 117 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
esp_err_t i2s_del_channel(i2s_chan_handle_t handle);
# 129 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
esp_err_t i2s_channel_get_info(i2s_chan_handle_t handle, i2s_chan_info_t *chan_info);
# 143 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
esp_err_t i2s_channel_enable(i2s_chan_handle_t handle);
# 157 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
esp_err_t i2s_channel_disable(i2s_chan_handle_t handle);
# 179 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
esp_err_t i2s_channel_preload_data(i2s_chan_handle_t tx_handle, const void *src, size_t size, size_t *bytes_loaded);
# 197 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
esp_err_t i2s_channel_write(i2s_chan_handle_t handle, const void *src, size_t size, size_t *bytes_written, uint32_t timeout_ms);
# 215 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
esp_err_t i2s_channel_read(i2s_chan_handle_t handle, void *dest, size_t size, size_t *bytes_read, uint32_t timeout_ms);
# 233 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_common.h"
esp_err_t i2s_channel_register_event_callback(i2s_chan_handle_t handle, const i2s_event_callbacks_t *callbacks, void *user_data);
# 18 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h" 2
# 211 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
typedef struct {

    i2s_data_bit_width_t data_bit_width;
    i2s_slot_bit_width_t slot_bit_width;
    i2s_slot_mode_t slot_mode;





    i2s_std_slot_mask_t slot_mask;
    uint32_t ws_width;
    
# 223 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h" 3 4
   _Bool 
# 223 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
                           ws_pol;
    
# 224 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h" 3 4
   _Bool 
# 224 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
                           bit_shift;



    
# 228 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h" 3 4
   _Bool 
# 228 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
                           left_align;
    
# 229 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h" 3 4
   _Bool 
# 229 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
                           big_endian;
    
# 230 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h" 3 4
   _Bool 
# 230 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
                           bit_order_lsb;

} i2s_std_slot_config_t;




typedef struct {

    uint32_t sample_rate_hz;
    i2s_clock_src_t clk_src;



    uint32_t ext_clk_freq_hz;



    i2s_mclk_multiple_t mclk_multiple;




} i2s_std_clk_config_t;




typedef struct {
    gpio_num_t mclk;
    gpio_num_t bclk;
    gpio_num_t ws;
    gpio_num_t dout;
    gpio_num_t din;
    struct {
        uint32_t mclk_inv: 1;
        uint32_t bclk_inv: 1;
        uint32_t ws_inv: 1;
    } invert_flags;
} i2s_std_gpio_config_t;




typedef struct {
    i2s_std_clk_config_t clk_cfg;
    i2s_std_slot_config_t slot_cfg;
    i2s_std_gpio_config_t gpio_cfg;
} i2s_std_config_t;
# 297 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
esp_err_t i2s_channel_init_std_mode(i2s_chan_handle_t handle, const i2s_std_config_t *std_cfg);
# 312 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
esp_err_t i2s_channel_reconfig_std_clock(i2s_chan_handle_t handle, const i2s_std_clk_config_t *clk_cfg);
# 329 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
esp_err_t i2s_channel_reconfig_std_slot(i2s_chan_handle_t handle, const i2s_std_slot_config_t *slot_cfg);
# 344 "/Users/mdahal01/Documents/esp-idf/components/driver/i2s/include/driver/i2s_std.h"
esp_err_t i2s_channel_reconfig_std_gpio(i2s_chan_handle_t handle, const i2s_std_gpio_config_t *gpio_cfg);
# 13 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 1
# 11 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_private/esp_wifi_types_private.h" 1
# 20 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_private/esp_wifi_types_private.h"
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/queue.h" 1 3 4
# 21 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_private/esp_wifi_types_private.h" 2

# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_interface.h" 1
# 17 "/Users/mdahal01/Documents/esp-idf/components/esp_hw_support/include/esp_interface.h"
typedef enum {
    ESP_IF_WIFI_STA = 0,
    ESP_IF_WIFI_AP,
    ESP_IF_WIFI_NAN,
    ESP_IF_ETH,
    ESP_IF_MAX
} esp_interface_t;
# 23 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_private/esp_wifi_types_private.h" 2
# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_event/include/esp_event_base.h" 1






       
# 20 "/Users/mdahal01/Documents/esp-idf/components/esp_event/include/esp_event_base.h"
typedef const char* esp_event_base_t;
typedef void* esp_event_loop_handle_t;
typedef void (*esp_event_handler_t)(void* event_handler_arg,
                                        esp_event_base_t event_base,
                                        int32_t event_id,
                                        void* event_data);
typedef void* esp_event_handler_instance_t;
# 24 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_private/esp_wifi_types_private.h" 2
# 12 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 2

# 1 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_he_types.h" 1






       
# 23 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_he_types.h"
typedef enum {
    ESP_WIFI_ACI_VO,
    ESP_WIFI_ACI_VI,
    ESP_WIFI_ACI_BE,
    ESP_WIFI_ACI_BK,
    ESP_WIFI_ACI_MAX,
} esp_wifi_aci_t;




enum {
    ESP_CSI_ACQUIRE_STBC_HELTF1,
    ESP_CSI_ACQUIRE_STBC_HELTF2,
    ESP_CSI_ACQUIRE_STBC_SAMPLE_HELTFS,
};




typedef struct {
    uint32_t enable : 1;
    uint32_t acquire_csi_legacy : 1;
    uint32_t acquire_csi_ht20 : 1;
    uint32_t acquire_csi_ht40 : 1;
    uint32_t acquire_csi_su : 1;
    uint32_t acquire_csi_mu : 1;
    uint32_t acquire_csi_dcm : 1;
    uint32_t acquire_csi_beamformed : 1;
    uint32_t acquire_csi_he_stbc : 2;



    uint32_t val_scale_cfg : 2;
    uint32_t dump_ack_en : 1;
    uint32_t reserved : 19;
} wifi_csi_acquire_config_t;




typedef struct {
    uint32_t id : 2;
    uint32_t uph_id : 4;
    uint32_t ul_pw_headroom : 5;
    uint32_t min_tx_pw_flag : 1;
    uint32_t rsvd : 2;
    uint32_t ctrl_id : 4;
    uint32_t rx_nss : 3;
    uint32_t bw : 2;
    uint32_t ul_mu_disable : 1;
    uint32_t tx_nsts : 3;
    uint32_t er_su_disable : 1;
    uint32_t dl_mu_mimo_resounding_recommendation : 1;
    uint32_t ul_mu_data_disable : 1;
    uint32_t padding : 2;
} esp_wifi_htc_omc_t;




typedef enum {
    TWT_REQUEST,
    TWT_SUGGEST,
    TWT_DEMAND,
    TWT_GROUPING,
    TWT_ACCEPT,
    TWT_ALTERNATE,
    TWT_DICTATE,
    TWT_REJECT,
} wifi_twt_setup_cmds_t;




typedef struct
{
    wifi_twt_setup_cmds_t setup_cmd;
    uint16_t trigger :1;
    uint16_t flow_type :1;
    uint16_t flow_id :3;


    uint16_t wake_invl_expn :5;
    uint16_t wake_duration_unit :1;
    uint16_t reserved :5;
    uint8_t min_wake_dura;
    uint16_t wake_invl_mant;
    uint16_t twt_id;
    uint16_t timeout_time_ms;
} wifi_twt_setup_config_t;




typedef enum {
    HE_SU_ERSU_1_LTF_0_8_US_GI,
    HE_SU_ERSU_2_LTF_0_8_US_GI,
    HE_SU_ERSU_2_LTF_1_6_US_GI,
    HE_SU_ERSU_4_LTF_3_2_US_GI,
} he_su_gi_and_ltf_type_t;




typedef enum {
    RX_BB_FORMAT_11B = 0,
    RX_BB_FORMAT_11G = 1,
    RX_BB_FORMAT_HT = 2,
    RX_BB_FORMAT_VHT = 3,
    RX_BB_FORMAT_HE_SU = 4,
    RX_BB_FORMAT_HE_MU = 5,
    RX_BB_FORMAT_HE_ERSU = 6,
    RX_BB_FORMAT_HE_TB = 7,
} wifi_rx_bb_format_t;




typedef struct {
    signed rssi : 8;
    unsigned rate : 5;
    unsigned : 1;
    unsigned : 2;
    unsigned : 12;
    unsigned rxmatch0 : 1;
    unsigned rxmatch1 : 1;
    unsigned rxmatch2 : 1;
    unsigned rxmatch3 : 1;
    uint32_t he_siga1;
    unsigned rxend_state : 8;
    uint16_t he_siga2;
    unsigned : 7;
    unsigned is_group : 1;
    unsigned timestamp : 32;
    unsigned : 15;
    unsigned : 15;
    unsigned : 2;
    signed noise_floor : 8;
    unsigned channel : 4;
    unsigned second : 4;
    unsigned : 8;
    unsigned : 8;
    unsigned : 32;
    unsigned : 32;
    unsigned : 2;
    unsigned : 4;
    unsigned : 2;
    unsigned rx_channel_estimate_len : 10;
    unsigned rx_channel_estimate_info_vld : 1;
    unsigned : 1;
    unsigned : 11;
    unsigned : 1;
    unsigned : 24;
    unsigned cur_bb_format : 4;
    unsigned cur_single_mpdu : 1;
    unsigned : 3;
    unsigned : 32;
    unsigned : 32;
    unsigned : 32;
    unsigned : 32;
    unsigned : 32;
    unsigned : 32;
    unsigned : 32;
    unsigned : 32;
    unsigned : 8;
    unsigned he_sigb_len : 6;
    unsigned : 2;
    unsigned : 8;
    unsigned : 8;
    unsigned : 32;
    unsigned : 7;
    unsigned : 1;
    unsigned : 8;
    unsigned : 16;
    unsigned sig_len : 14;
    unsigned : 2;
    unsigned dump_len : 14;
    unsigned : 2;
    unsigned rx_state : 8;
    unsigned : 24;
} __attribute__((packed)) esp_wifi_rxctrl_t;


typedef struct {
    wifi_twt_setup_config_t config;
    esp_err_t status;
    uint8_t reason;
    uint64_t target_wake_time;
} wifi_event_sta_itwt_setup_t;


typedef struct {
    uint8_t flow_id;
} wifi_event_sta_itwt_teardown_t;




typedef enum {
    ITWT_PROBE_FAIL,
    ITWT_PROBE_SUCCESS,
    ITWT_PROBE_TIMEOUT,

    ITWT_PROBE_STA_DISCONNECTED,
} wifi_itwt_probe_status_t;


typedef struct {
    wifi_itwt_probe_status_t status;
    uint8_t reason;
} wifi_event_sta_itwt_probe_t;


typedef struct {
    esp_err_t status;
    uint8_t flow_id_bitmap;
    uint32_t actual_suspend_time_ms[8];
} wifi_event_sta_itwt_suspend_t;




typedef enum {
    TWT_TYPE_INDIVIDUAL,
    TWT_TYPE_BROADCAST,
    TWT_TYPE_MAX,
} wifi_twt_type_t;


typedef struct {
    
# 254 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_he_types.h" 3 4
   _Bool 
# 254 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_he_types.h"
        post_wakeup_event;
} wifi_twt_config_t;


typedef struct {
    wifi_twt_type_t twt_type;
    uint8_t flow_id;
} wifi_event_sta_twt_wakeup_t;
# 14 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 2






typedef enum {
    WIFI_MODE_NULL = 0,
    WIFI_MODE_STA,
    WIFI_MODE_AP,
    WIFI_MODE_APSTA,
    WIFI_MODE_NAN,
    WIFI_MODE_MAX
} wifi_mode_t;

typedef enum {
    WIFI_IF_STA = ESP_IF_WIFI_STA,
    WIFI_IF_AP = ESP_IF_WIFI_AP,



    WIFI_IF_MAX
} wifi_interface_t;







typedef enum {
    WIFI_COUNTRY_POLICY_AUTO,
    WIFI_COUNTRY_POLICY_MANUAL,
} wifi_country_policy_t;


typedef struct {
    char cc[3];
    uint8_t schan;
    uint8_t nchan;
    int8_t max_tx_power;
    wifi_country_policy_t policy;
} wifi_country_t;



typedef enum {
    WIFI_AUTH_OPEN = 0,
    WIFI_AUTH_WEP,
    WIFI_AUTH_WPA_PSK,
    WIFI_AUTH_WPA2_PSK,
    WIFI_AUTH_WPA_WPA2_PSK,
    WIFI_AUTH_ENTERPRISE,
    WIFI_AUTH_WPA2_ENTERPRISE = WIFI_AUTH_ENTERPRISE,
    WIFI_AUTH_WPA3_PSK,
    WIFI_AUTH_WPA2_WPA3_PSK,
    WIFI_AUTH_WAPI_PSK,
    WIFI_AUTH_OWE,
    WIFI_AUTH_WPA3_ENT_192,
    WIFI_AUTH_WPA3_EXT_PSK,
    WIFI_AUTH_WPA3_EXT_PSK_MIXED_MODE,
    WIFI_AUTH_MAX
} wifi_auth_mode_t;

typedef enum {
    WIFI_REASON_UNSPECIFIED = 1,
    WIFI_REASON_AUTH_EXPIRE = 2,
    WIFI_REASON_AUTH_LEAVE = 3,
    WIFI_REASON_ASSOC_EXPIRE = 4,
    WIFI_REASON_ASSOC_TOOMANY = 5,
    WIFI_REASON_NOT_AUTHED = 6,
    WIFI_REASON_NOT_ASSOCED = 7,
    WIFI_REASON_ASSOC_LEAVE = 8,
    WIFI_REASON_ASSOC_NOT_AUTHED = 9,
    WIFI_REASON_DISASSOC_PWRCAP_BAD = 10,
    WIFI_REASON_DISASSOC_SUPCHAN_BAD = 11,
    WIFI_REASON_BSS_TRANSITION_DISASSOC = 12,
    WIFI_REASON_IE_INVALID = 13,
    WIFI_REASON_MIC_FAILURE = 14,
    WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT = 15,
    WIFI_REASON_GROUP_KEY_UPDATE_TIMEOUT = 16,
    WIFI_REASON_IE_IN_4WAY_DIFFERS = 17,
    WIFI_REASON_GROUP_CIPHER_INVALID = 18,
    WIFI_REASON_PAIRWISE_CIPHER_INVALID = 19,
    WIFI_REASON_AKMP_INVALID = 20,
    WIFI_REASON_UNSUPP_RSN_IE_VERSION = 21,
    WIFI_REASON_INVALID_RSN_IE_CAP = 22,
    WIFI_REASON_802_1X_AUTH_FAILED = 23,
    WIFI_REASON_CIPHER_SUITE_REJECTED = 24,
    WIFI_REASON_TDLS_PEER_UNREACHABLE = 25,
    WIFI_REASON_TDLS_UNSPECIFIED = 26,
    WIFI_REASON_SSP_REQUESTED_DISASSOC = 27,
    WIFI_REASON_NO_SSP_ROAMING_AGREEMENT = 28,
    WIFI_REASON_BAD_CIPHER_OR_AKM = 29,
    WIFI_REASON_NOT_AUTHORIZED_THIS_LOCATION = 30,
    WIFI_REASON_SERVICE_CHANGE_PERCLUDES_TS = 31,
    WIFI_REASON_UNSPECIFIED_QOS = 32,
    WIFI_REASON_NOT_ENOUGH_BANDWIDTH = 33,
    WIFI_REASON_MISSING_ACKS = 34,
    WIFI_REASON_EXCEEDED_TXOP = 35,
    WIFI_REASON_STA_LEAVING = 36,
    WIFI_REASON_END_BA = 37,
    WIFI_REASON_UNKNOWN_BA = 38,
    WIFI_REASON_TIMEOUT = 39,
    WIFI_REASON_PEER_INITIATED = 46,
    WIFI_REASON_AP_INITIATED = 47,
    WIFI_REASON_INVALID_FT_ACTION_FRAME_COUNT = 48,
    WIFI_REASON_INVALID_PMKID = 49,
    WIFI_REASON_INVALID_MDE = 50,
    WIFI_REASON_INVALID_FTE = 51,
    WIFI_REASON_TRANSMISSION_LINK_ESTABLISH_FAILED = 67,
    WIFI_REASON_ALTERATIVE_CHANNEL_OCCUPIED = 68,

    WIFI_REASON_BEACON_TIMEOUT = 200,
    WIFI_REASON_NO_AP_FOUND = 201,
    WIFI_REASON_AUTH_FAIL = 202,
    WIFI_REASON_ASSOC_FAIL = 203,
    WIFI_REASON_HANDSHAKE_TIMEOUT = 204,
    WIFI_REASON_CONNECTION_FAIL = 205,
    WIFI_REASON_AP_TSF_RESET = 206,
    WIFI_REASON_ROAMING = 207,
    WIFI_REASON_ASSOC_COMEBACK_TIME_TOO_LONG = 208,
    WIFI_REASON_SA_QUERY_TIMEOUT = 209,
    WIFI_REASON_NO_AP_FOUND_W_COMPATIBLE_SECURITY = 210,
    WIFI_REASON_NO_AP_FOUND_IN_AUTHMODE_THRESHOLD = 211,
    WIFI_REASON_NO_AP_FOUND_IN_RSSI_THRESHOLD = 212,
} wifi_err_reason_t;

typedef enum {
    WIFI_SECOND_CHAN_NONE = 0,
    WIFI_SECOND_CHAN_ABOVE,
    WIFI_SECOND_CHAN_BELOW,
} wifi_second_chan_t;

typedef enum {
    WIFI_SCAN_TYPE_ACTIVE = 0,
    WIFI_SCAN_TYPE_PASSIVE,
} wifi_scan_type_t;


typedef struct {
    uint32_t min;
    uint32_t max;

} wifi_active_scan_time_t;


typedef struct {
    wifi_active_scan_time_t active;
    uint32_t passive;

} wifi_scan_time_t;


typedef struct {
    uint8_t *ssid;
    uint8_t *bssid;
    uint8_t channel;
    
# 172 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 172 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        show_hidden;
    wifi_scan_type_t scan_type;
    wifi_scan_time_t scan_time;
    uint8_t home_chan_dwell_time;
} wifi_scan_config_t;

typedef enum {
    WIFI_CIPHER_TYPE_NONE = 0,
    WIFI_CIPHER_TYPE_WEP40,
    WIFI_CIPHER_TYPE_WEP104,
    WIFI_CIPHER_TYPE_TKIP,
    WIFI_CIPHER_TYPE_CCMP,
    WIFI_CIPHER_TYPE_TKIP_CCMP,
    WIFI_CIPHER_TYPE_AES_CMAC128,
    WIFI_CIPHER_TYPE_SMS4,
    WIFI_CIPHER_TYPE_GCMP,
    WIFI_CIPHER_TYPE_GCMP256,
    WIFI_CIPHER_TYPE_AES_GMAC128,
    WIFI_CIPHER_TYPE_AES_GMAC256,
    WIFI_CIPHER_TYPE_UNKNOWN,
} wifi_cipher_type_t;





typedef enum {
    WIFI_ANT_ANT0,
    WIFI_ANT_ANT1,
    WIFI_ANT_MAX,
} wifi_ant_t;


typedef struct {
    uint8_t bss_color:6;
    uint8_t partial_bss_color:1;
    uint8_t bss_color_disabled:1;
    uint8_t bssid_index;
} wifi_he_ap_info_t;


typedef struct {
    uint8_t bssid[6];
    uint8_t ssid[33];
    uint8_t primary;
    wifi_second_chan_t second;
    int8_t rssi;
    wifi_auth_mode_t authmode;
    wifi_cipher_type_t pairwise_cipher;
    wifi_cipher_type_t group_cipher;
    wifi_ant_t ant;
    uint32_t phy_11b:1;
    uint32_t phy_11g:1;
    uint32_t phy_11n:1;
    uint32_t phy_lr:1;
    uint32_t phy_11ax:1;
    uint32_t wps:1;
    uint32_t ftm_responder:1;
    uint32_t ftm_initiator:1;
    uint32_t reserved:24;
    wifi_country_t country;
    wifi_he_ap_info_t he_ap;
} wifi_ap_record_t;

typedef enum {
    WIFI_FAST_SCAN = 0,
    WIFI_ALL_CHANNEL_SCAN,
}wifi_scan_method_t;

typedef enum {
    WIFI_CONNECT_AP_BY_SIGNAL = 0,
    WIFI_CONNECT_AP_BY_SECURITY,
}wifi_sort_method_t;


typedef struct {
    int8_t rssi;
    wifi_auth_mode_t authmode;

}wifi_scan_threshold_t;

typedef enum {
    WIFI_PS_NONE,
    WIFI_PS_MIN_MODEM,
    WIFI_PS_MAX_MODEM,
} wifi_ps_type_t;







typedef enum {
    WIFI_BW_HT20 = 1,
    WIFI_BW_HT40,
} wifi_bandwidth_t;


typedef struct {
    
# 272 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 272 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        capable;
    
# 273 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 273 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        required;
} wifi_pmf_config_t;


typedef enum {
    WPA3_SAE_PWE_UNSPECIFIED,
    WPA3_SAE_PWE_HUNT_AND_PECK,
    WPA3_SAE_PWE_HASH_TO_ELEMENT,
    WPA3_SAE_PWE_BOTH,
} wifi_sae_pwe_method_t;


typedef enum {
    WPA3_SAE_PK_MODE_AUTOMATIC = 0,
    WPA3_SAE_PK_MODE_ONLY = 1,
    WPA3_SAE_PK_MODE_DISABLED = 2,
} wifi_sae_pk_mode_t;


typedef struct {
    uint8_t ssid[32];
    uint8_t password[64];
    uint8_t ssid_len;
    uint8_t channel;
    wifi_auth_mode_t authmode;
    uint8_t ssid_hidden;
    uint8_t max_connection;
    uint16_t beacon_interval;
    wifi_cipher_type_t pairwise_cipher;
    
# 302 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 302 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        ftm_responder;
    wifi_pmf_config_t pmf_cfg;
    wifi_sae_pwe_method_t sae_pwe_h2e;
} wifi_ap_config_t;



typedef struct {
    uint8_t ssid[32];
    uint8_t password[64];
    wifi_scan_method_t scan_method;
    
# 313 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 313 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        bssid_set;
    uint8_t bssid[6];
    uint8_t channel;
    uint16_t listen_interval;
    wifi_sort_method_t sort_method;
    wifi_scan_threshold_t threshold;
    wifi_pmf_config_t pmf_cfg;
    uint32_t rm_enabled:1;
    uint32_t btm_enabled:1;
    uint32_t mbo_enabled:1;
    uint32_t ft_enabled:1;
    uint32_t owe_enabled:1;
    uint32_t transition_disable:1;
    uint32_t reserved:26;
    wifi_sae_pwe_method_t sae_pwe_h2e;
    wifi_sae_pk_mode_t sae_pk_mode;
    uint8_t failure_retry_cnt;

    uint32_t he_dcm_set:1;
    uint32_t he_dcm_max_constellation_tx:2;
    uint32_t he_dcm_max_constellation_rx:2;
    uint32_t he_mcs9_enabled:1;
    uint32_t he_su_beamformee_disabled:1;
    uint32_t he_trig_su_bmforming_feedback_disabled:1;
    uint32_t he_trig_mu_bmforming_partial_feedback_disabled:1;
    uint32_t he_trig_cqi_feedback_disabled:1;
    uint32_t he_reserved:22;
    uint8_t sae_h2e_identifier[32];
} wifi_sta_config_t;





typedef struct {
    uint8_t op_channel;
    uint8_t master_pref;
    uint8_t scan_time;
    uint16_t warm_up_sec;
} wifi_nan_config_t;







typedef union {
    wifi_ap_config_t ap;
    wifi_sta_config_t sta;
    wifi_nan_config_t nan;
} wifi_config_t;


typedef struct {
    uint8_t mac[6];
    int8_t rssi;
    uint32_t phy_11b:1;
    uint32_t phy_11g:1;
    uint32_t phy_11n:1;
    uint32_t phy_lr:1;
    uint32_t phy_11ax:1;
    uint32_t is_mesh_child:1;
    uint32_t reserved:26;
} wifi_sta_info_t;
# 388 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
typedef struct {
    wifi_sta_info_t sta[(10)];
    int num;
} wifi_sta_list_t;

typedef enum {
    WIFI_STORAGE_FLASH,
    WIFI_STORAGE_RAM,
} wifi_storage_t;






typedef enum {
    WIFI_VND_IE_TYPE_BEACON,
    WIFI_VND_IE_TYPE_PROBE_REQ,
    WIFI_VND_IE_TYPE_PROBE_RESP,
    WIFI_VND_IE_TYPE_ASSOC_REQ,
    WIFI_VND_IE_TYPE_ASSOC_RESP,
} wifi_vendor_ie_type_t;






typedef enum {
    WIFI_VND_IE_ID_0,
    WIFI_VND_IE_ID_1,
} wifi_vendor_ie_id_t;






typedef enum
{
    WIFI_PHY_MODE_LR,
    WIFI_PHY_MODE_11B,
    WIFI_PHY_MODE_11G,
    WIFI_PHY_MODE_HT20,
    WIFI_PHY_MODE_HT40,
    WIFI_PHY_MODE_HE20,
} wifi_phy_mode_t;






typedef struct {
    uint8_t element_id;
    uint8_t length;
    uint8_t vendor_oui[3];
    uint8_t vendor_oui_type;
    uint8_t payload[0];
} vendor_ie_data_t;


typedef esp_wifi_rxctrl_t wifi_pkt_rx_ctrl_t;
# 507 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
typedef struct {
    wifi_pkt_rx_ctrl_t rx_ctrl;
    uint8_t payload[0];
} wifi_promiscuous_pkt_t;







typedef enum {
    WIFI_PKT_MGMT,
    WIFI_PKT_CTRL,
    WIFI_PKT_DATA,
    WIFI_PKT_MISC,
} wifi_promiscuous_pkt_type_t;
# 547 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
typedef struct {
    uint32_t filter_mask;
} wifi_promiscuous_filter_t;
# 560 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
typedef wifi_csi_acquire_config_t wifi_csi_config_t;
# 578 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
typedef struct {
    wifi_pkt_rx_ctrl_t rx_ctrl;
    uint8_t mac[6];
    uint8_t dmac[6];
    
# 582 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 582 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        first_word_invalid;
    int8_t *buf;
    uint16_t len;
    uint8_t *hdr;
    uint8_t *payload;
    uint16_t payload_len;
    uint16_t rx_seq;
} wifi_csi_info_t;





typedef struct {
    uint8_t gpio_select: 1,
            gpio_num: 7;
} wifi_ant_gpio_t;





typedef struct {
    wifi_ant_gpio_t gpio_cfg[4];
} wifi_ant_gpio_config_t;





typedef enum {
    WIFI_ANT_MODE_ANT0,
    WIFI_ANT_MODE_ANT1,
    WIFI_ANT_MODE_AUTO,
    WIFI_ANT_MODE_MAX,
} wifi_ant_mode_t;





typedef struct {
    wifi_ant_mode_t rx_ant_mode;
    wifi_ant_t rx_ant_default;
    wifi_ant_mode_t tx_ant_mode;
    uint8_t enabled_ant0: 4,
                    enabled_ant1: 4;
} wifi_ant_config_t;
# 640 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
typedef int (* wifi_action_rx_cb_t)(uint8_t *hdr, uint8_t *payload,
                                    size_t len, uint8_t channel);






typedef struct {
    wifi_interface_t ifx;
    uint8_t dest_mac[6];
    
# 651 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 651 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        no_ack;
    wifi_action_rx_cb_t rx_cb;
    uint32_t data_len;
    uint8_t data[0];
} wifi_action_tx_req_t;





typedef struct {
    uint8_t resp_mac[6];
    uint8_t channel;
    uint8_t frm_count;
    uint16_t burst_period;
    
# 666 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 666 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        use_get_report_api;

} wifi_ftm_initiator_cfg_t;





typedef struct {
    
# 675 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 675 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
               enable;
    uint8_t loss_timeout;
    uint8_t loss_threshold;
    uint8_t delta_intr_early;
    uint8_t delta_loss_timeout;

    uint8_t beacon_abort: 1,
                broadcast_wakeup: 1,
                reserved: 6;
    uint8_t tsf_time_sync_deviation;
    uint16_t modem_state_consecutive;
    uint16_t rf_ctrl_wait_cycle;

} wifi_beacon_monitor_config_t;
# 704 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
typedef enum {
    NAN_PUBLISH_SOLICITED,
    NAN_PUBLISH_UNSOLICITED,
    NAN_SUBSCRIBE_ACTIVE,
    NAN_SUBSCRIBE_PASSIVE,
} wifi_nan_service_type_t;





typedef struct {
    char service_name[256];
    wifi_nan_service_type_t type;
    char matching_filter[256];
    char svc_info[64];
    uint8_t single_replied_event:1;
    uint8_t datapath_reqd:1;
    uint8_t reserved:6;
} wifi_nan_publish_cfg_t;





typedef struct {
    char service_name[256];
    wifi_nan_service_type_t type;
    char matching_filter[256];
    char svc_info[64];
    uint8_t single_match_event:1;
    uint8_t reserved:7;
} wifi_nan_subscribe_cfg_t;





typedef struct {
    uint8_t inst_id;
    uint8_t peer_inst_id;
    uint8_t peer_mac[6];
    char svc_info[64];
} wifi_nan_followup_params_t;





typedef struct {
    uint8_t pub_id;
    uint8_t peer_mac[6];
    
# 756 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 756 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        confirm_required;
} wifi_nan_datapath_req_t;





typedef struct {
    
# 764 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 764 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        accept;
    uint8_t ndp_id;
    uint8_t peer_mac[6];
} wifi_nan_datapath_resp_t;





typedef struct {
    uint8_t ndp_id;
    uint8_t peer_mac[6];
} wifi_nan_datapath_end_req_t;





typedef enum {
    WIFI_PHY_RATE_1M_L = 0x00,
    WIFI_PHY_RATE_2M_L = 0x01,
    WIFI_PHY_RATE_5M_L = 0x02,
    WIFI_PHY_RATE_11M_L = 0x03,
    WIFI_PHY_RATE_2M_S = 0x05,
    WIFI_PHY_RATE_5M_S = 0x06,
    WIFI_PHY_RATE_11M_S = 0x07,
    WIFI_PHY_RATE_48M = 0x08,
    WIFI_PHY_RATE_24M = 0x09,
    WIFI_PHY_RATE_12M = 0x0A,
    WIFI_PHY_RATE_6M = 0x0B,
    WIFI_PHY_RATE_54M = 0x0C,
    WIFI_PHY_RATE_36M = 0x0D,
    WIFI_PHY_RATE_18M = 0x0E,
    WIFI_PHY_RATE_9M = 0x0F,
# 814 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
    WIFI_PHY_RATE_MCS0_LGI = 0x10,
    WIFI_PHY_RATE_MCS1_LGI = 0x11,
    WIFI_PHY_RATE_MCS2_LGI = 0x12,
    WIFI_PHY_RATE_MCS3_LGI = 0x13,
    WIFI_PHY_RATE_MCS4_LGI = 0x14,
    WIFI_PHY_RATE_MCS5_LGI = 0x15,
    WIFI_PHY_RATE_MCS6_LGI = 0x16,
    WIFI_PHY_RATE_MCS7_LGI = 0x17,

    WIFI_PHY_RATE_MCS8_LGI,
    WIFI_PHY_RATE_MCS9_LGI,
# 841 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
    WIFI_PHY_RATE_MCS0_SGI,
    WIFI_PHY_RATE_MCS1_SGI,
    WIFI_PHY_RATE_MCS2_SGI,
    WIFI_PHY_RATE_MCS3_SGI,
    WIFI_PHY_RATE_MCS4_SGI,
    WIFI_PHY_RATE_MCS5_SGI,
    WIFI_PHY_RATE_MCS6_SGI,
    WIFI_PHY_RATE_MCS7_SGI,

    WIFI_PHY_RATE_MCS8_SGI,
    WIFI_PHY_RATE_MCS9_SGI,

    WIFI_PHY_RATE_LORA_250K = 0x29,
    WIFI_PHY_RATE_LORA_500K = 0x2A,
    WIFI_PHY_RATE_MAX,
} wifi_phy_rate_t;


typedef enum {
    WIFI_EVENT_WIFI_READY = 0,
    WIFI_EVENT_SCAN_DONE,
    WIFI_EVENT_STA_START,
    WIFI_EVENT_STA_STOP,
    WIFI_EVENT_STA_CONNECTED,
    WIFI_EVENT_STA_DISCONNECTED,
    WIFI_EVENT_STA_AUTHMODE_CHANGE,

    WIFI_EVENT_STA_WPS_ER_SUCCESS,
    WIFI_EVENT_STA_WPS_ER_FAILED,
    WIFI_EVENT_STA_WPS_ER_TIMEOUT,
    WIFI_EVENT_STA_WPS_ER_PIN,
    WIFI_EVENT_STA_WPS_ER_PBC_OVERLAP,

    WIFI_EVENT_AP_START,
    WIFI_EVENT_AP_STOP,
    WIFI_EVENT_AP_STACONNECTED,
    WIFI_EVENT_AP_STADISCONNECTED,
    WIFI_EVENT_AP_PROBEREQRECVED,

    WIFI_EVENT_FTM_REPORT,


    WIFI_EVENT_STA_BSS_RSSI_LOW,
    WIFI_EVENT_ACTION_TX_STATUS,
    WIFI_EVENT_ROC_DONE,

    WIFI_EVENT_STA_BEACON_TIMEOUT,

    WIFI_EVENT_CONNECTIONLESS_MODULE_WAKE_INTERVAL_START,

    WIFI_EVENT_AP_WPS_RG_SUCCESS,
    WIFI_EVENT_AP_WPS_RG_FAILED,
    WIFI_EVENT_AP_WPS_RG_TIMEOUT,
    WIFI_EVENT_AP_WPS_RG_PIN,
    WIFI_EVENT_AP_WPS_RG_PBC_OVERLAP,

    WIFI_EVENT_ITWT_SETUP,
    WIFI_EVENT_ITWT_TEARDOWN,
    WIFI_EVENT_ITWT_PROBE,
    WIFI_EVENT_ITWT_SUSPEND,
    WIFI_EVENT_TWT_WAKEUP,

    WIFI_EVENT_NAN_STARTED,
    WIFI_EVENT_NAN_STOPPED,
    WIFI_EVENT_NAN_SVC_MATCH,
    WIFI_EVENT_NAN_REPLIED,
    WIFI_EVENT_NAN_RECEIVE,
    WIFI_EVENT_NDP_INDICATION,
    WIFI_EVENT_NDP_CONFIRM,
    WIFI_EVENT_NDP_TERMINATED,
    WIFI_EVENT_HOME_CHANNEL_CHANGE,

    WIFI_EVENT_MAX,
} wifi_event_t;



extern esp_event_base_t const WIFI_EVENT;



typedef struct {
    uint32_t status;
    uint8_t number;
    uint8_t scan_id;
} wifi_event_sta_scan_done_t;


typedef struct {
    uint8_t ssid[32];
    uint8_t ssid_len;
    uint8_t bssid[6];
    uint8_t channel;
    wifi_auth_mode_t authmode;
    uint16_t aid;
} wifi_event_sta_connected_t;


typedef struct {
    uint8_t ssid[32];
    uint8_t ssid_len;
    uint8_t bssid[6];
    uint8_t reason;
    int8_t rssi;
} wifi_event_sta_disconnected_t;


typedef struct {
    wifi_auth_mode_t old_mode;
    wifi_auth_mode_t new_mode;
} wifi_event_sta_authmode_change_t;


typedef struct {
    uint8_t pin_code[8];
} wifi_event_sta_wps_er_pin_t;


typedef enum {
    WPS_FAIL_REASON_NORMAL = 0,
    WPS_FAIL_REASON_RECV_M2D,
    WPS_FAIL_REASON_MAX
} wifi_event_sta_wps_fail_reason_t;






typedef struct {
    uint8_t ap_cred_cnt;
    struct {
        uint8_t ssid[32];
        uint8_t passphrase[64];
    } ap_cred[3];
} wifi_event_sta_wps_er_success_t;


typedef struct {
    uint8_t mac[6];
    uint8_t aid;
    
# 982 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 982 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        is_mesh_child;
} wifi_event_ap_staconnected_t;


typedef struct {
    uint8_t mac[6];
    uint8_t aid;
    
# 989 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 989 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        is_mesh_child;
    uint8_t reason;
} wifi_event_ap_stadisconnected_t;


typedef struct {
    int rssi;
    uint8_t mac[6];
} wifi_event_ap_probe_req_rx_t;


typedef struct {
    int32_t rssi;
} wifi_event_bss_rssi_low_t;


typedef struct {
    uint8_t old_chan;
    wifi_second_chan_t old_snd;
    uint8_t new_chan;
    wifi_second_chan_t new_snd;
} wifi_event_home_channel_change_t;





typedef enum {
    FTM_STATUS_SUCCESS = 0,
    FTM_STATUS_UNSUPPORTED,
    FTM_STATUS_CONF_REJECTED,
    FTM_STATUS_NO_RESPONSE,
    FTM_STATUS_FAIL,
    FTM_STATUS_NO_VALID_MSMT,
    FTM_STATUS_USER_TERM,
} wifi_ftm_status_t;


typedef struct {
    uint8_t dlog_token;
    int8_t rssi;
    uint32_t rtt;
    uint64_t t1;
    uint64_t t2;
    uint64_t t3;
    uint64_t t4;
} wifi_ftm_report_entry_t;


typedef struct {
    uint8_t peer_mac[6];
    wifi_ftm_status_t status;
    uint32_t rtt_raw;
    uint32_t rtt_est;
    uint32_t dist_est;
    wifi_ftm_report_entry_t *ftm_report_data;

    uint8_t ftm_report_num_entries;
} wifi_event_ftm_report_t;
# 1057 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
typedef struct {
    wifi_interface_t ifx;
    uint32_t context;
    uint8_t da[6];
    uint8_t status;
} wifi_event_action_tx_status_t;


typedef struct {
    uint32_t context;
} wifi_event_roc_done_t;


typedef struct {
    uint8_t pin_code[8];
} wifi_event_ap_wps_rg_pin_t;

typedef enum {
    WPS_AP_FAIL_REASON_NORMAL = 0,
    WPS_AP_FAIL_REASON_CONFIG,
    WPS_AP_FAIL_REASON_AUTH,
    WPS_AP_FAIL_REASON_MAX,
} wps_fail_reason_t;


typedef struct {
    wps_fail_reason_t reason;
    uint8_t peer_macaddr[6];
} wifi_event_ap_wps_rg_fail_reason_t;


typedef struct {
    uint8_t peer_macaddr[6];
} wifi_event_ap_wps_rg_success_t;


typedef struct {
    uint8_t subscribe_id;
    uint8_t publish_id;
    uint8_t pub_if_mac[6];
    
# 1097 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h" 3 4
   _Bool 
# 1097 "/Users/mdahal01/Documents/esp-idf/components/esp_wifi/include/esp_wifi_types.h"
        update_pub_id;
} wifi_event_nan_svc_match_t;


typedef struct {
    uint8_t publish_id;
    uint8_t subscribe_id;
    uint8_t sub_if_mac[6];
} wifi_event_nan_replied_t;


typedef struct {
    uint8_t inst_id;
    uint8_t peer_inst_id;
    uint8_t peer_if_mac[6];
    uint8_t peer_svc_info[64];
} wifi_event_nan_receive_t;


typedef struct {
    uint8_t publish_id;
    uint8_t ndp_id;
    uint8_t peer_nmi[6];
    uint8_t peer_ndi[6];
    uint8_t svc_info[64];
} wifi_event_ndp_indication_t;


typedef struct {
    uint8_t status;
    uint8_t ndp_id;
    uint8_t peer_nmi[6];
    uint8_t peer_ndi[6];
    uint8_t own_ndi[6];
    uint8_t svc_info[64];
} wifi_event_ndp_confirm_t;


typedef struct {
    uint8_t reason;
    uint8_t ndp_id;
    uint8_t init_ndi[6];
} wifi_event_ndp_terminated_t;
# 14 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h" 2
# 330 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h"
typedef int32_t mp_int_t;
typedef uint32_t mp_uint_t;
typedef long mp_off_t;

# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 1 3 4
# 28 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 3 4

# 28 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 3 4
typedef __uint8_t u_int8_t;


typedef __uint16_t u_int16_t;


typedef __uint32_t u_int32_t;


typedef __uint64_t u_int64_t;

typedef __intptr_t register_t;
# 50 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 3 4
# 1 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/select.h" 1 3 4
# 11 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/select.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 1 3 4
# 12 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/select.h" 2 3 4

# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/select.h" 1 3 4
# 14 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/select.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_sigset.h" 1 3 4
# 41 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_sigset.h" 3 4
typedef unsigned long __sigset_t;
# 15 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/select.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_timeval.h" 1 3 4
# 37 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_timeval.h" 3 4
typedef __suseconds_t suseconds_t;




typedef __int_least64_t time_t;
# 54 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_timeval.h" 3 4
struct timeval {
 time_t tv_sec;
 suseconds_t tv_usec;
};
# 16 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/select.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/timespec.h" 1 3 4
# 38 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/timespec.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_timespec.h" 1 3 4
# 47 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_timespec.h" 3 4
struct timespec {
 time_t tv_sec;
 long tv_nsec;
};
# 39 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/timespec.h" 2 3 4
# 58 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/timespec.h" 3 4
struct itimerspec {
 struct timespec it_interval;
 struct timespec it_value;
};
# 17 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/select.h" 2 3 4



typedef __sigset_t sigset_t;
# 38 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/select.h" 3 4
typedef unsigned long __fd_mask;

typedef __fd_mask fd_mask;
# 52 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/select.h" 3 4
typedef struct fd_set {
 __fd_mask __fds_bits[(((64) + ((((int)sizeof(__fd_mask) * 8)) - 1)) / (((int)sizeof(__fd_mask) * 8)))];
} fd_set;
# 78 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/select.h" 3 4


int select (int __n, fd_set *__readfds, fd_set *__writefds, fd_set *__exceptfds, struct timeval *__timeout)
                                                   ;

int pselect (int __n, fd_set *__readfds, fd_set *__writefds, fd_set *__exceptfds, const struct timespec *__timeout, const sigset_t *__set)

                           ;



# 14 "/Users/mdahal01/Documents/esp-idf/components/newlib/platform_include/sys/select.h" 2 3 4
# 51 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 2 3 4




typedef __uint32_t in_addr_t;




typedef __uint16_t in_port_t;



typedef __uintptr_t u_register_t;






typedef unsigned char u_char;



typedef unsigned short u_short;



typedef unsigned int u_int;



typedef unsigned long u_long;







typedef unsigned short ushort;
typedef unsigned int uint;
typedef unsigned long ulong;



typedef __blkcnt_t blkcnt_t;




typedef __blksize_t blksize_t;




typedef unsigned long clock_t;
# 118 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 3 4
typedef __daddr_t daddr_t;


typedef char * caddr_t;




typedef __fsblkcnt_t fsblkcnt_t;
typedef __fsfilcnt_t fsfilcnt_t;




typedef __id_t id_t;




typedef __ino_t ino_t;
# 159 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 3 4
typedef __dev_t dev_t;



typedef __uid_t uid_t;



typedef __gid_t gid_t;




typedef __pid_t pid_t;




typedef __key_t key_t;
# 187 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 3 4
typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __clockid_t clockid_t;





typedef __timer_t timer_t;





typedef __useconds_t useconds_t;
# 218 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 3 4
typedef __int64_t sbintime_t;


# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_pthreadtypes.h" 1 3 4
# 23 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_pthreadtypes.h" 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/sched.h" 1 3 4
# 48 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/sched.h" 3 4
struct sched_param {
  int sched_priority;
# 61 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/sched.h" 3 4
};


int sched_yield( void );
# 24 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_pthreadtypes.h" 2 3 4
# 32 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_pthreadtypes.h" 3 4
typedef __uint32_t pthread_t;
# 61 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_pthreadtypes.h" 3 4
typedef struct {
  int is_initialized;
  void *stackaddr;
  int stacksize;
  int contentionscope;
  int inheritsched;
  int schedpolicy;
  struct sched_param schedparam;





  int detachstate;
} pthread_attr_t;
# 154 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_pthreadtypes.h" 3 4
typedef __uint32_t pthread_mutex_t;

typedef struct {
  int is_initialized;
# 166 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/_pthreadtypes.h" 3 4
  int type;

  int recursive;
} pthread_mutexattr_t;






typedef __uint32_t pthread_cond_t;



typedef struct {
  int is_initialized;
  clock_t clock;



} pthread_condattr_t;



typedef __uint32_t pthread_key_t;

typedef struct {
  int is_initialized;
  int init_executed;
} pthread_once_t;
# 222 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 2 3 4
# 1 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/machine/types.h" 1 3 4
# 223 "/Users/mdahal01/.espressif/tools/riscv32-esp-elf/esp-13.2.0_20230928/riscv32-esp-elf/riscv32-esp-elf/sys-include/sys/types.h" 2 3 4
# 335 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h" 2
# 374 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h"

# 374 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/ports/esp32/mpconfigport.h"
void boardctrl_startup(void);
# 92 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/py/mpconfig.h" 2
# 840 "/Users/mdahal01/Documents/GitHub/micropythonDeepsleep/py/mpconfig.h"
typedef float mp_float_t;
# 30 "<stdin>" 2





QCFG(BYTES_IN_LEN, (1))
QCFG(BYTES_IN_HASH, (2))

Q()
Q(*)
Q(_)
Q(/)

Q(>>> )
Q(... )


Q(%#o)
Q(%#x)




Q({:#b})
Q( )
Q(\n)
Q(maximum recursion depth exceeded)
Q(<module>)
Q(<lambda>)
Q(<listcomp>)
Q(<dictcomp>)
Q(<setcomp>)
Q(<genexpr>)
Q(<string>)
Q(<stdin>)
Q(utf-8)


Q(.frozen)
# 109 "<stdin>"
Q(/lib)
Q(ADC)

Q(ADC)

Q(ADCBlock)

Q(ADCBlock)

Q(ADDR_LEN)

Q(AF_INET)

Q(AF_INET6)

Q(AP_IF)

Q(ARRAY)

Q(ATTN_0DB)

Q(ATTN_11DB)

Q(ATTN_2_5DB)

Q(ATTN_6DB)

Q(AUTH_CHAP)

Q(AUTH_MAX)

Q(AUTH_NONE)

Q(AUTH_OPEN)

Q(AUTH_OWE)

Q(AUTH_PAP)

Q(AUTH_WAPI_PSK)

Q(AUTH_WEP)

Q(AUTH_WPA2_ENTERPRISE)

Q(AUTH_WPA2_PSK)

Q(AUTH_WPA2_WPA3_PSK)

Q(AUTH_WPA3_ENT_192)

Q(AUTH_WPA3_EXT_PSK)

Q(AUTH_WPA3_EXT_PSK_MIXED_MODE)

Q(AUTH_WPA3_PSK)

Q(AUTH_WPA_PSK)

Q(AUTH_WPA_WPA2_PSK)

Q(AUTO)

Q(ArithmeticError)

Q(ArithmeticError)

Q(AssertionError)

Q(AssertionError)

Q(AssertionError)

Q(AttributeError)

Q(AttributeError)

Q(BFINT16)

Q(BFINT32)

Q(BFINT8)

Q(BFUINT16)

Q(BFUINT32)

Q(BFUINT8)

Q(BF_LEN)

Q(BF_POS)

Q(BIG_ENDIAN)

Q(BLE)

Q(BLE)

Q(BOOT)

Q(BaseException)

Q(BaseException)

Q(BaseException)

Q(BufferedWriter)

Q(BufferedWriter)

Q(BytesIO)

Q(BytesIO)

Q(CERT_NONE)

Q(CERT_OPTIONAL)

Q(CERT_REQUIRED)

Q(CTS)

Q(CancelledError)

Q(DEEPSLEEP)

Q(DEEPSLEEP_RESET)

Q(DESC)

Q(DRIVE_0)

Q(DRIVE_1)

Q(DRIVE_2)

Q(DRIVE_3)

Q(DeflateIO)

Q(DeflateIO)

Q(EACCES)

Q(EACCES)

Q(EADDRINUSE)

Q(EADDRINUSE)

Q(EAGAIN)

Q(EAGAIN)

Q(EALREADY)

Q(EALREADY)

Q(EBADF)

Q(EBADF)

Q(ECONNABORTED)

Q(ECONNABORTED)

Q(ECONNREFUSED)

Q(ECONNREFUSED)

Q(ECONNRESET)

Q(ECONNRESET)

Q(EEXIST)

Q(EEXIST)

Q(EHOSTUNREACH)

Q(EHOSTUNREACH)

Q(EINPROGRESS)

Q(EINPROGRESS)

Q(EINVAL)

Q(EINVAL)

Q(EIO)

Q(EIO)

Q(EISDIR)

Q(EISDIR)

Q(ENOBUFS)

Q(ENOBUFS)

Q(ENODEV)

Q(ENODEV)

Q(ENOENT)

Q(ENOENT)

Q(ENOMEM)

Q(ENOMEM)

Q(ENOTCONN)

Q(ENOTCONN)

Q(EOFError)

Q(EOFError)

Q(EOPNOTSUPP)

Q(EOPNOTSUPP)

Q(EPERM)

Q(EPERM)

Q(ESPNowBase)

Q(ESPNowBase)

Q(ETH_CONNECTED)

Q(ETH_DISCONNECTED)

Q(ETH_GOT_IP)

Q(ETH_INITIALIZED)

Q(ETH_STARTED)

Q(ETH_STOPPED)

Q(ETIMEDOUT)

Q(ETIMEDOUT)

Q(EXT0_WAKE)

Q(EXT1_WAKE)

Q(Ellipsis)

Q(Ellipsis)

Q(Exception)

Q(Exception)

Q(FLAG_INDICATE)

Q(FLAG_NOTIFY)

Q(FLAG_READ)

Q(FLAG_WRITE)

Q(FLAG_WRITE_NO_RESPONSE)

Q(FLOAT32)

Q(FLOAT64)

Q(FileIO)

Q(FileIO)

Q(FileIO)

Q(FrameBuffer)

Q(FrameBuffer)

Q(FrameBuffer1)

Q(GPIO_WAKE)

Q(GS2_HMSB)

Q(GS4_HMSB)

Q(GS8)

Q(GZIP)

Q(GeneratorExit)

Q(GeneratorExit)

Q(HARD_RESET)

Q(HEAP_DATA)

Q(HEAP_EXEC)

Q(I2C)

Q(I2C)

Q(IF_AP)

Q(IF_STA)

Q(IN)

Q(INCL)

Q(INT)

Q(INT16)

Q(INT32)

Q(INT64)

Q(INT8)

Q(INV_CTS)

Q(INV_RTS)

Q(INV_RX)

Q(INV_TX)

Q(IOBase)

Q(IOBase)

Q(IPPROTO_IP)

Q(IPPROTO_TCP)

Q(IPPROTO_UDP)

Q(IP_ADD_MEMBERSHIP)

Q(IRQ)

Q(IRQ_BREAK)

Q(IRQ_FALLING)

Q(IRQ_RISING)

Q(IRQ_RX)

Q(IRQ_RXIDLE)

Q(ImportError)

Q(ImportError)

Q(IndentationError)

Q(IndentationError)

Q(IndexError)

Q(IndexError)

Q(KEY_LEN)

Q(KeyError)

Q(KeyError)

Q(KeyboardInterrupt)

Q(KeyboardInterrupt)

Q(LAN)

Q(LAN)

Q(LITTLE_ENDIAN)

Q(LOG_DEBUG)

Q(LOG_ERROR)

Q(LOG_INFO)

Q(LOG_NONE)

Q(LOG_VERBOSE)

Q(LOG_WARNING)

Q(LONG)

Q(LONGLONG)

Q(LSB)

Q(LockType)

Q(LookupError)

Q(LookupError)

Q(MAX_DATA_LEN)

Q(MAX_ENCRYPT_PEER_NUM)

Q(MAX_TOTAL_PEER_NUM)

Q(MBEDTLS_VERSION)

Q(MODE_11B)

Q(MODE_11G)

Q(MODE_11N)

Q(MODE_LR)

Q(MONO_HLSB)

Q(MONO_HMSB)

Q(MONO_VLSB)

Q(MSB)

Q(MVLSB)

Q(MemoryError)

Q(MemoryError)

Q(NATIVE)

Q(NVS)

Q(NVS)

Q(NameError)

Q(NameError)

Q(None)

Q(NoneType)

Q(NotImplemented)

Q(NotImplemented)

Q(NotImplementedError)

Q(NotImplementedError)

Q(ONE_SHOT)

Q(ONE_SHOT)

Q(OPEN_DRAIN)

Q(OSError)

Q(OSError)

Q(OUT)

Q(OrderedDict)

Q(OrderedDict)

Q(OrderedDict)

Q(OverflowError)

Q(OverflowError)

Q(PERIODIC)

Q(PERIODIC)

Q(PHY_DM9051)

Q(PHY_DP83848)

Q(PHY_IP101)

Q(PHY_KSZ8041)

Q(PHY_KSZ8081)

Q(PHY_KSZ8851SNL)

Q(PHY_LAN8710)

Q(PHY_LAN8720)

Q(PHY_RTL8201)

Q(PHY_W5500)

Q(PIN_WAKE)

Q(PM_NONE)

Q(PM_PERFORMANCE)

Q(PM_POWERSAVE)

Q(POLLERR)

Q(POLLHUP)

Q(POLLIN)

Q(POLLOUT)

Q(PPP)

Q(PPP)

Q(PROTOCOL_DTLS_CLIENT)

Q(PROTOCOL_DTLS_SERVER)

Q(PROTOCOL_TLS_CLIENT)

Q(PROTOCOL_TLS_SERVER)

Q(PTR)

Q(PULL_DOWN)

Q(PULL_UP)

Q(PULSE_MAX)

Q(PWM)

Q(PWM)

Q(PWRON_RESET)

Q(Partition)

Q(Partition)

Q(Pin)

Q(Pin)

Q(RAW)

Q(RGB565)

Q(RMT)

Q(RMT)

Q(RTC)

Q(RTC)

Q(RTS)

Q(RUNNING)

Q(RingIO)

Q(RingIO)

Q(RuntimeError)

Q(RuntimeError)

Q(SDCard)

Q(SDCard)

Q(SEC_OPEN)

Q(SEC_OWE)

Q(SEC_WAPI)

Q(SEC_WEP)

Q(SEC_WPA)

Q(SEC_WPA2)

Q(SEC_WPA2_ENT)

Q(SEC_WPA2_WPA3)

Q(SEC_WPA3)

Q(SEC_WPA3_ENT_192)

Q(SEC_WPA3_EXT_PSK)

Q(SEC_WPA3_EXT_PSK_MIXED_MODE)

Q(SEC_WPA_WPA2)

Q(SHORT)

Q(SLEEP)

Q(SOCK_DGRAM)

Q(SOCK_RAW)

Q(SOCK_STREAM)

Q(SOFT_RESET)

Q(SOL_SOCKET)

Q(SO_BINDTODEVICE)

Q(SO_BROADCAST)

Q(SO_REUSEADDR)

Q(SPI)

Q(SPI)

Q(SSLContext)

Q(SSLContext)

Q(SSLSocket)

Q(STAT_ASSOC_FAIL)

Q(STAT_BEACON_TIMEOUT)

Q(STAT_CONNECTING)

Q(STAT_CONNECT_FAIL)

Q(STAT_GOT_IP)

Q(STAT_HANDSHAKE_TIMEOUT)

Q(STAT_IDLE)

Q(STAT_NO_AP_FOUND)

Q(STAT_NO_AP_FOUND_IN_AUTHMODE_THRESHOLD)

Q(STAT_NO_AP_FOUND_IN_RSSI_THRESHOLD)

Q(STAT_NO_AP_FOUND_W_COMPATIBLE_SECURITY)

Q(STAT_WRONG_PASSWORD)

Q(STA_IF)

Q(Signal)

Q(Signal)

Q(SoftI2C)

Q(SoftI2C)

Q(SoftSPI)

Q(SoftSPI)

Q(StopAsyncIteration)

Q(StopAsyncIteration)

Q(StopAsyncIteration)

Q(StopIteration)

Q(StopIteration)

Q(StringIO)

Q(StringIO)

Q(SyntaxError)

Q(SyntaxError)

Q(SystemExit)

Q(SystemExit)

Q(TCP_NODELAY)

Q(TIMER_WAKE)

Q(TOUCHPAD_WAKE)

Q(TYPE_APP)

Q(TYPE_DATA)

Q(Task)

Q(Task)

Q(TaskQueue)

Q(TaskQueue)

Q(TextIOWrapper)

Q(TextIOWrapper)

Q(TextIOWrapper)

Q(Timer)

Q(Timer)

Q(TypeError)

Q(TypeError)

Q(UART)

Q(UART)

Q(UINT)

Q(UINT16)

Q(UINT32)

Q(UINT64)

Q(UINT8)

Q(ULONG)

Q(ULONGLONG)

Q(ULP_WAKE)

Q(USHORT)

Q(UUID)

Q(UUID)

Q(UnicodeError)

Q(UnicodeError)

Q(VOID)

Q(ValueError)

Q(ValueError)

Q(VfsFat)

Q(VfsFat)

Q(VfsFat)

Q(VfsLfs2)

Q(VfsLfs2)

Q(VfsLfs2)

Q(ViperTypeError)

Q(ViperTypeError)

Q(WAKEUP_ALL_LOW)

Q(WAKEUP_ANY_HIGH)

Q(WAKE_HIGH)

Q(WAKE_LOW)

Q(WDT)

Q(WDT)

Q(WDT_RESET)

Q(WIDTH_12BIT)

Q(WLAN)

Q(WLAN)

Q(ZLIB)

Q(ZeroDivisionError)

Q(ZeroDivisionError)

Q(_)

Q(_0x0a_)

Q(__abs__)

Q(__add__)

Q(__aenter__)

Q(__aenter__)

Q(__aexit__)

Q(__aexit__)

Q(__aiter__)

Q(__and__)

Q(__anext__)

Q(__bases__)

Q(__bool__)

Q(__build_class__)

Q(__build_class__)

Q(__call__)

Q(__class__)

Q(__class__)

Q(__class__)

Q(__class__)

Q(__class__)

Q(__class__)

Q(__class__)

Q(__complex__)

Q(__contains__)

Q(__contains__)

Q(__contains__)

Q(__del__)

Q(__del__)

Q(__del__)

Q(__del__)

Q(__del__)

Q(__del__)

Q(__del__)

Q(__del__)

Q(__del__)

Q(__del__)

Q(__del__)

Q(__delattr__)

Q(__delattr__)

Q(__delattr__)

Q(__delattr__)

Q(__delete__)

Q(__delete__)

Q(__delete__)

Q(__delitem__)

Q(__delitem__)

Q(__dict__)

Q(__dict__)

Q(__dict__)

Q(__dir__)

Q(__divmod__)

Q(__enter__)

Q(__enter__)

Q(__enter__)

Q(__enter__)

Q(__enter__)

Q(__enter__)

Q(__enter__)

Q(__enter__)

Q(__eq__)

Q(__eq__)

Q(__exit__)

Q(__exit__)

Q(__exit__)

Q(__exit__)

Q(__exit__)

Q(__exit__)

Q(__exit__)

Q(__exit__)

Q(__file__)

Q(__file__)

Q(__file__)

Q(__float__)

Q(__floordiv__)

Q(__ge__)

Q(__get__)

Q(__get__)

Q(__get__)

Q(__getattr__)

Q(__getattr__)

Q(__getattr__)

Q(__getattr__)

Q(__getitem__)

Q(__getitem__)

Q(__getitem__)

Q(__getitem__)

Q(__globals__)

Q(__gt__)

Q(__hash__)

Q(__iadd__)

Q(__iand__)

Q(__ifloordiv__)

Q(__ilshift__)

Q(__imatmul__)

Q(__imod__)

Q(__import__)

Q(__import__)

Q(__imul__)

Q(__init__)

Q(__init__)

Q(__init__)

Q(__init__)

Q(__init__)

Q(__init__)

Q(__init__)

Q(__int__)

Q(__invert__)

Q(__ior__)

Q(__ipow__)

Q(__irshift__)

Q(__isub__)

Q(__iter__)

Q(__itruediv__)

Q(__ixor__)

Q(__le__)

Q(__len__)

Q(__lshift__)

Q(__lt__)

Q(__main__)

Q(__main__)

Q(__matmul__)

Q(__mod__)

Q(__module__)

Q(__mul__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__name__)

Q(__ne__)

Q(__neg__)

Q(__new__)

Q(__new__)

Q(__new__)

Q(__next__)

Q(__next__)

Q(__next__)

Q(__next__)

Q(__or__)

Q(__path__)

Q(__path__)

Q(__path__)

Q(__path__)

Q(__pos__)

Q(__pow__)

Q(__qualname__)

Q(__radd__)

Q(__rand__)

Q(__repl_print__)

Q(__repl_print__)

Q(__repr__)

Q(__repr__)

Q(__reversed__)

Q(__rfloordiv__)

Q(__rlshift__)

Q(__rmatmul__)

Q(__rmod__)

Q(__rmul__)

Q(__ror__)

Q(__rpow__)

Q(__rrshift__)

Q(__rshift__)

Q(__rsub__)

Q(__rtruediv__)

Q(__rxor__)

Q(__set__)

Q(__set__)

Q(__set__)

Q(__setattr__)

Q(__setattr__)

Q(__setattr__)

Q(__setattr__)

Q(__setitem__)

Q(__setitem__)

Q(__str__)

Q(__sub__)

Q(__traceback__)

Q(__truediv__)

Q(__xor__)

Q(_asyncio)

Q(_asyncio)

Q(_brace_open__colon__hash_b_brace_close_)

Q(_build)

Q(_dot__dot__dot__space_)

Q(_dot_frozen)

Q(_espnow)

Q(_espnow)

Q(_gt__gt__gt__space_)

Q(_lt_dictcomp_gt_)

Q(_lt_dictcomp_gt_)

Q(_lt_genexpr_gt_)

Q(_lt_genexpr_gt_)

Q(_lt_lambda_gt_)

Q(_lt_lambda_gt_)

Q(_lt_listcomp_gt_)

Q(_lt_listcomp_gt_)

Q(_lt_module_gt_)

Q(_lt_module_gt_)

Q(_lt_setcomp_gt_)

Q(_lt_setcomp_gt_)

Q(_lt_stdin_gt_)

Q(_lt_stdin_gt_)

Q(_lt_string_gt_)

Q(_machine)

Q(_mpy)

Q(_onewire)

Q(_percent__hash_o)

Q(_percent__hash_x)

Q(_slash_)

Q(_slash_)

Q(_slash_)

Q(_slash_)

Q(_slash_)

Q(_slash_)

Q(_slash_lib)

Q(_space_)

Q(_star_)

Q(_star_)

Q(_star_)

Q(_task_queue)

Q(_thread)

Q(_thread)

Q(_webrepl)

Q(_webrepl)

Q(_webrepl)

Q(_webrepl)

Q(a2b_base64)

Q(abs)

Q(abs_tol)

Q(accept)

Q(acos)

Q(acosh)

Q(acquire)

Q(active)

Q(active)

Q(active)

Q(active)

Q(active)

Q(add)

Q(add_peer)

Q(addr)

Q(addr4)

Q(addr4)

Q(addr4)

Q(addr_mode)

Q(addressof)

Q(addrsize)

Q(adv_data)

Q(aes)

Q(aes)

Q(all)

Q(alloc_emergency_exception_buf)

Q(allocate_lock)

Q(any)

Q(any)

Q(any)

Q(any)

Q(append)

Q(append)

Q(append)

Q(appendleft)

Q(arg)

Q(args)

Q(argv)

Q(array)

Q(array)

Q(array)

Q(array)

Q(asin)

Q(asinh)

Q(atan)

Q(atan2)

Q(atanh)

Q(atten)

Q(atten)

Q(authmode)

Q(authmode)

Q(authmode)

Q(b2a_base64)

Q(baudrate)

Q(baudrate)

Q(baudrate)

Q(baudrate)

Q(bin)

Q(binascii)

Q(binascii)

Q(bind)

Q(bits)

Q(bits)

Q(bits)

Q(bits)

Q(bitstream)

Q(bitstream_channel)

Q(blit)

Q(block)

Q(block_size)

Q(bluetooth)

Q(bluetooth)

Q(board)

Q(board)

Q(bond)

Q(bool)

Q(bool)

Q(bool)

Q(bool)

Q(bound_method)

Q(bssid)

Q(btree)

Q(btree)

Q(btree)

Q(buffer)

Q(buffering)

Q(builtins)

Q(builtins)

Q(bytearray)

Q(bytearray)

Q(bytearray_at)

Q(bytecode)

Q(byteorder)

Q(bytes)

Q(bytes)

Q(bytes)

Q(bytes_at)

Q(cachesize)

Q(calcsize)

Q(callable)

Q(callback)

Q(cancel)

Q(cd)

Q(ceil)

Q(center)

Q(channel)

Q(channel)

Q(channel)

Q(chdir)

Q(chdir)

Q(chdir)

Q(chdir)

Q(chdir)

Q(choice)

Q(chr)

Q(cipher)

Q(classmethod)

Q(classmethod)

Q(clear)

Q(clear)

Q(clear)

Q(clock_div)

Q(clock_div)

Q(close)

Q(close)

Q(close)

Q(close)

Q(close)

Q(close)

Q(close)

Q(close)

Q(close)

Q(close)

Q(close)

Q(close)

Q(close)

Q(closure)

Q(cmath)

Q(cmath)

Q(code)

Q(collect)

Q(collections)

Q(collections)

Q(commit)

Q(compile)

Q(compile)

Q(complex)

Q(complex)

Q(config)

Q(config)

Q(config)

Q(config)

Q(config)

Q(connect)

Q(connect)

Q(connect)

Q(connect)

Q(connectable)

Q(const)

Q(const)

Q(copy)

Q(copy)

Q(copy)

Q(copy)

Q(copysign)

Q(coro)

Q(cos)

Q(cos)

Q(cosh)

Q(count)

Q(count)

Q(count)

Q(count)

Q(country)

Q(crc32)

Q(crc8)

Q(cryptolib)

Q(cryptolib)

Q(cs)

Q(cs)

Q(cts)

Q(cur_task)

Q(cur_task)

Q(data)

Q(data)

Q(datetime)

Q(decode)

Q(decrypt)

Q(deepsleep)

Q(default)

Q(deflate)

Q(deflate)

Q(degrees)

Q(deinit)

Q(deinit)

Q(deinit)

Q(deinit)

Q(deinit)

Q(deinit)

Q(del_peer)

Q(delattr)

Q(deleter)

Q(deque)

Q(deque)

Q(dhcp4)

Q(dhcp4)

Q(dhcp_hostname)

Q(dhcp_hostname)

Q(dht_readinto)

Q(dict)

Q(dict)

Q(dict_view)

Q(difference)

Q(difference)

Q(difference_update)

Q(digest)

Q(digest)

Q(digest)

Q(dir)

Q(disable)

Q(disable_irq)

Q(discard)

Q(disconnect)

Q(divmod)

Q(dns)

Q(dns)

Q(do_handshake_on_connect)

Q(doc)

Q(done)

Q(drive)

Q(dump)

Q(dumps)

Q(dupterm)

Q(dupterm_notify)

Q(duty)

Q(duty)

Q(duty_ns)

Q(duty_ns)

Q(duty_u16)

Q(duty_u16)

Q(e)

Q(e)

Q(ellipse)

Q(enable)

Q(enable_irq)

Q(encode)

Q(encoding)

Q(encrypt)

Q(encrypt)

Q(end)

Q(endswith)

Q(enumerate)

Q(enumerate)

Q(erase_key)

Q(erf)

Q(erfc)

Q(errno)

Q(errno)

Q(errno)

Q(errno)

Q(errorcode)

Q(esp)

Q(esp)

Q(esp32)

Q(esp32)

Q(essid)

Q(essid)

Q(eval)

Q(eval)

Q(exec)

Q(exec)

Q(execfile)

Q(exit)

Q(exit)

Q(exp)

Q(exp)

Q(expm1)

Q(extend)

Q(extend)

Q(extend)

Q(fabs)

Q(factorial)

Q(feed)

Q(file)

Q(file)

Q(fileno)

Q(fill)

Q(fill_rect)

Q(filter)

Q(filter)

Q(find)

Q(find)

Q(firstbit)

Q(firstbit)

Q(firstbit)

Q(flags)

Q(flags)

Q(flash_erase)

Q(flash_read)

Q(flash_size)

Q(flash_user_start)

Q(flash_write)

Q(float)

Q(float)

Q(floor)

Q(flow)

Q(flush)

Q(flush)

Q(flush)

Q(flush)

Q(flush)

Q(flush)

Q(fmod)

Q(format)

Q(framebuf)

Q(framebuf)

Q(freq)

Q(freq)

Q(freq)

Q(freq)

Q(freq)

Q(freq)

Q(freq)

Q(frexp)

Q(from_bytes)

Q(fromhex)

Q(fromkeys)

Q(frozenset)

Q(frozenset)

Q(function)

Q(function)

Q(function)

Q(function)

Q(function)

Q(function)

Q(function)

Q(function)

Q(function)

Q(function)

Q(gamma)

Q(gap_advertise)

Q(gap_connect)

Q(gap_disconnect)

Q(gap_name)

Q(gap_name)

Q(gap_pair)

Q(gap_passkey)

Q(gap_scan)

Q(gattc_discover_characteristics)

Q(gattc_discover_descriptors)

Q(gattc_discover_services)

Q(gattc_exchange_mtu)

Q(gattc_read)

Q(gattc_write)

Q(gatts_indicate)

Q(gatts_notify)

Q(gatts_read)

Q(gatts_register_services)

Q(gatts_set_buffer)

Q(gatts_write)

Q(gc)

Q(gc)

Q(generator)

Q(generator)

Q(generator)

Q(get)

Q(get)

Q(get_blob)

Q(get_ciphers)

Q(get_i32)

Q(get_ident)

Q(get_next_update)

Q(get_peer)

Q(get_peers)

Q(getaddrinfo)

Q(getattr)

Q(getcwd)

Q(getcwd)

Q(getcwd)

Q(getcwd)

Q(getpeercert)

Q(getrandbits)

Q(getter)

Q(getvalue)

Q(globals)

Q(gmtime)

Q(gpio_matrix_in)

Q(gpio_matrix_out)

Q(group)

Q(gw4)

Q(gw4)

Q(gw4)

Q(handler)

Q(handler)

Q(hard)

Q(hasattr)

Q(hash)

Q(hashlib)

Q(hashlib)

Q(heap_lock)

Q(heap_unlock)

Q(heapify)

Q(heappop)

Q(heappush)

Q(heapq)

Q(heapq)

Q(help)

Q(hex)

Q(hex)

Q(hexlify)

Q(hidden)

Q(hidden)

Q(hline)

Q(hold)

Q(hostname)

Q(hostname)

Q(hostname)

Q(id)

Q(id)

Q(id)

Q(id)

Q(id)

Q(id)

Q(idf_heap_info)

Q(idle)

Q(idle_level)

Q(ifconfig)

Q(ifconfig)

Q(ifconfig)

Q(ifidx)

Q(ifname)

Q(ifname)

Q(ifname)

Q(ilistdir)

Q(ilistdir)

Q(ilistdir)

Q(ilistdir)

Q(ilistdir)

Q(imag)

Q(implementation)

Q(index)

Q(index)

Q(index)

Q(indices)

Q(inf)

Q(info)

Q(info)

Q(init)

Q(init)

Q(init)

Q(init)

Q(init)

Q(init)

Q(init)

Q(init)

Q(init)

Q(input)

Q(insert)

Q(int)

Q(int)

Q(int)

Q(int)

Q(int)

Q(intersection)

Q(intersection)

Q(intersection_update)

Q(interval_us)

Q(invert)

Q(invert)

Q(invert)

Q(io)

Q(io)

Q(io)

Q(ioctl)

Q(ioctl)

Q(ioctl)

Q(ioctl)

Q(ioctl)

Q(ipconfig)

Q(ipconfig)

Q(ipconfig)

Q(ipconfig)

Q(ipoll)

Q(irq)

Q(irq)

Q(irq)

Q(irq)

Q(irq)

Q(isalpha)

Q(isclose)

Q(isconnected)

Q(isconnected)

Q(isconnected)

Q(isdigit)

Q(isdisjoint)

Q(isdisjoint)

Q(isenabled)

Q(isfinite)

Q(isinf)

Q(isinstance)

Q(islower)

Q(isnan)

Q(isspace)

Q(issubclass)

Q(issubset)

Q(issubset)

Q(issuperset)

Q(issuperset)

Q(isupper)

Q(items)

Q(items)

Q(iter)

Q(iterable)

Q(iterator)

Q(iterator)

Q(iterator)

Q(iterator)

Q(iterator)

Q(iterator)

Q(join)

Q(json)

Q(json)

Q(kbd_intr)

Q(keepends)

Q(key)

Q(key)

Q(key)

Q(keys)

Q(keys)

Q(keys)

Q(label)

Q(ldexp)

Q(le_secure)

Q(len)

Q(level)

Q(lgamma)

Q(libc_ver)

Q(lightsleep)

Q(line)

Q(list)

Q(list)

Q(listdir)

Q(listen)

Q(little)

Q(little)

Q(little)

Q(lmk)

Q(load)

Q(load_cert_chain)

Q(load_verify_locations)

Q(loads)

Q(locals)

Q(localtime)

Q(lock)

Q(locked)

Q(log)

Q(log)

Q(log10)

Q(log10)

Q(log2)

Q(lookahead)

Q(loop)

Q(lower)

Q(lstrip)

Q(mac)

Q(mac)

Q(mac)

Q(mac)

Q(mac)

Q(machine)

Q(machine)

Q(machine)

Q(makefile)

Q(map)

Q(map)

Q(mark_app_valid_cancel_rollback)

Q(match)

Q(match)

Q(match)

Q(math)

Q(math)

Q(max)

Q(max_clients)

Q(max_clients)

Q(maximum_space_recursion_space_depth_space_exceeded)

Q(maxsize)

Q(mcu_temperature)

Q(md5)

Q(md5)

Q(mdc)

Q(mdio)

Q(mem)

Q(mem16)

Q(mem32)

Q(mem8)

Q(mem_alloc)

Q(mem_free)

Q(mem_info)

Q(memaddr)

Q(memory)

Q(memoryview)

Q(memoryview)

Q(micropython)

Q(micropython)

Q(micropython)

Q(micropython)

Q(min)

Q(minkeypage)

Q(miso)

Q(miso)

Q(miso)

Q(miso)

Q(mitm)

Q(mkdir)

Q(mkdir)

Q(mkdir)

Q(mkdir)

Q(mkfs)

Q(mkfs)

Q(mkfs)

Q(mktime)

Q(mod_peer)

Q(mode)

Q(mode)

Q(mode)

Q(modf)

Q(modify)

Q(module)

Q(modules)

Q(modules)

Q(mosi)

Q(mosi)

Q(mosi)

Q(mosi)

Q(mount)

Q(mount)

Q(mount)

Q(mount)

Q(mount)

Q(mount)

Q(mtime)

Q(mtu)

Q(mtu)

Q(name)

Q(namedtuple)

Q(nan)

Q(native)

Q(network)

Q(network)

Q(newline)

Q(next)

Q(nodename)

Q(object)

Q(object)

Q(object)

Q(object)

Q(oct)

Q(off)

Q(off)

Q(on)

Q(on)

Q(onewire)

Q(open)

Q(open)

Q(open)

Q(open)

Q(open)

Q(open)

Q(opt_level)

Q(ord)

Q(os)

Q(os)

Q(osdebug)

Q(pack)

Q(pack_into)

Q(pagesize)

Q(parity)

Q(partition)

Q(password)

Q(password)

Q(password)

Q(path)

Q(peek)

Q(peer_count)

Q(peers_table)

Q(pend_throw)

Q(period)

Q(ph_key)

Q(phase)

Q(phase)

Q(phase)

Q(phase)

Q(phy_addr)

Q(phy_mode)

Q(phy_type)

Q(pi)

Q(pi)

Q(pin)

Q(pins)

Q(pixel)

Q(platform)

Q(platform)

Q(platform)

Q(platform)

Q(pm)

Q(pm)

Q(polar)

Q(polarity)

Q(polarity)

Q(polarity)

Q(poll)

Q(poll)

Q(poll)

Q(poly)

Q(pop)

Q(pop)

Q(pop)

Q(pop)

Q(pop)

Q(popitem)

Q(popleft)

Q(pow)

Q(pow)

Q(power)

Q(print)

Q(print_exception)

Q(progsize)

Q(property)

Q(property)

Q(protocol)

Q(protocol)

Q(ps1)

Q(ps2)

Q(ptr)

Q(ptr)

Q(ptr16)

Q(ptr16)

Q(ptr32)

Q(ptr32)

Q(ptr8)

Q(ptr8)

Q(pull)

Q(push)

Q(put)

Q(python_compiler)

Q(qstr_info)

Q(r)

Q(radians)

Q(randint)

Q(random)

Q(random)

Q(random)

Q(randrange)

Q(range)

Q(range)

Q(range)

Q(rate)

Q(rb)

Q(rb)

Q(re)

Q(re)

Q(re)

Q(read)

Q(read)

Q(read)

Q(read)

Q(read)

Q(read)

Q(read)

Q(read)

Q(read)

Q(read)

Q(read)

Q(read)

Q(read)

Q(read_u16)

Q(read_uv)

Q(readbit)

Q(readblocks)

Q(readblocks)

Q(readblocks)

Q(readbyte)

Q(readfrom)

Q(readfrom_into)

Q(readfrom_mem)

Q(readfrom_mem_into)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readinto)

Q(readline)

Q(readline)

Q(readline)

Q(readline)

Q(readline)

Q(readline)

Q(readline)

Q(readline)

Q(readline)

Q(readline)

Q(readlines)

Q(readlines)

Q(readlines)

Q(readonly)

Q(readsize)

Q(real)

Q(reconnects)

Q(reconnects)

Q(rect)

Q(rect)

Q(recv)

Q(recv)

Q(recv_into)

Q(recvfrom)

Q(recvinto)

Q(ref_clk)

Q(ref_clk_mode)

Q(register)

Q(rel_tol)

Q(release)

Q(release)

Q(remove)

Q(remove)

Q(remove)

Q(remove)

Q(remove)

Q(remove)

Q(remove)

Q(remove)

Q(rename)

Q(rename)

Q(rename)

Q(rename)

Q(replace)

Q(repr)

Q(reset)

Q(reset)

Q(reset)

Q(reset_cause)

Q(resp_data)

Q(reverse)

Q(reverse)

Q(reversed)

Q(reversed)

Q(rfind)

Q(rindex)

Q(rmdir)

Q(rmdir)

Q(rmdir)

Q(rmdir)

Q(round)

Q(rpartition)

Q(rsplit)

Q(rssi)

Q(rstrip)

Q(rts)

Q(rx)

Q(rxbuf)

Q(rxbuf)

Q(rxbuf)

Q(scan)

Q(scan)

Q(schedule)

Q(sck)

Q(sck)

Q(sck)

Q(sck)

Q(scl)

Q(scl)

Q(scroll)

Q(sda)

Q(sda)

Q(search)

Q(search)

Q(security)

Q(security)

Q(seed)

Q(seek)

Q(seek)

Q(seek)

Q(select)

Q(select)

Q(select)

Q(self)

Q(send)

Q(send)

Q(send)

Q(send)

Q(send)

Q(sendall)

Q(sendall)

Q(sendbreak)

Q(sendto)

Q(sep)

Q(sep)

Q(separators)

Q(seq)

Q(server_hostname)

Q(server_side)

Q(set)

Q(set)

Q(set_blob)

Q(set_boot)

Q(set_ciphers)

Q(set_i32)

Q(set_pmk)

Q(setattr)

Q(setblocking)

Q(setblocking)

Q(setblocking)

Q(setblocking)

Q(setdefault)

Q(setsockopt)

Q(setter)

Q(settimeout)

Q(sha1)

Q(sha1)

Q(sha256)

Q(sha256)

Q(sin)

Q(sin)

Q(single)

Q(sinh)

Q(sizeof)

Q(sleep)

Q(sleep)

Q(sleep_ms)

Q(sleep_us)

Q(slice)

Q(slice)

Q(slot)

Q(socket)

Q(socket)

Q(socket)

Q(socket)

Q(soft_reset)

Q(sort)

Q(sorted)

Q(source_freq)

Q(spi)

Q(split)

Q(split)

Q(splitlines)

Q(sqrt)

Q(sqrt)

Q(ssid)

Q(ssid)

Q(stack_size)

Q(stack_use)

Q(start)

Q(start)

Q(start)

Q(start)

Q(start_new_thread)

Q(startswith)

Q(stat)

Q(stat)

Q(stat)

Q(stat)

Q(stat)

Q(state)

Q(state)

Q(staticmethod)

Q(staticmethod)

Q(stations)

Q(stats)

Q(status)

Q(status)

Q(status)

Q(statvfs)

Q(statvfs)

Q(statvfs)

Q(statvfs)

Q(stderr)

Q(stdin)

Q(stdout)

Q(step)

Q(step)

Q(stop)

Q(stop)

Q(stop)

Q(stop)

Q(str)

Q(str)

Q(str)

Q(str)

Q(stream)

Q(stream)

Q(strip)

Q(struct)

Q(struct)

Q(struct)

Q(struct)

Q(sub)

Q(sub)

Q(subtype)

Q(sum)

Q(super)

Q(super)

Q(super)

Q(symmetric_difference)

Q(symmetric_difference)

Q(symmetric_difference_update)

Q(sync)

Q(sync)

Q(sys)

Q(sys)

Q(sysname)

Q(tan)

Q(tanh)

Q(tau)

Q(tell)

Q(tell)

Q(tell)

Q(text)

Q(threshold)

Q(throw)

Q(throw)

Q(tick_hz)

Q(ticks_add)

Q(ticks_cpu)

Q(ticks_diff)

Q(ticks_ms)

Q(ticks_us)

Q(time)

Q(time)

Q(time)

Q(time_ns)

Q(time_pulse_us)

Q(timeout)

Q(timeout)

Q(timeout)

Q(timeout)

Q(timeout)

Q(timeout_char)

Q(timeout_ms)

Q(timeout_ms)

Q(tls)

Q(tls)

Q(to_bytes)

Q(toggle)

Q(trigger)

Q(trigger)

Q(trigger)

Q(trigger)

Q(trunc)

Q(tuple)

Q(tuple)

Q(tuple)

Q(tx)

Q(tx_carrier)

Q(txbuf)

Q(txdone)

Q(txpower)

Q(txpower)

Q(type)

Q(type)

Q(type)

Q(uctypes)

Q(uctypes)

Q(uctypes)

Q(uint)

Q(uint)

Q(umount)

Q(umount)

Q(umount)

Q(umount)

Q(umount)

Q(uname)

Q(unhexlify)

Q(uniform)

Q(union)

Q(union)

Q(unique_id)

Q(unlink)

Q(unpack)

Q(unpack_from)

Q(unregister)

Q(update)

Q(update)

Q(update)

Q(update)

Q(update)

Q(upper)

Q(urandom)

Q(username)

Q(usys)

Q(utf_hyphen_8)

Q(utf_hyphen_8)

Q(value)

Q(value)

Q(value)

Q(value)

Q(value)

Q(value)

Q(values)

Q(values)

Q(verify_callback)

Q(verify_callback)

Q(verify_mode)

Q(verify_mode)

Q(version)

Q(version)

Q(version)

Q(version_info)

Q(vfs)

Q(vfs)

Q(viper)

Q(vline)

Q(wait_done)

Q(wake)

Q(wake_gpio_pins)

Q(wake_on_ext0)

Q(wake_on_ext1)

Q(wake_on_touch)

Q(wake_on_ulp)

Q(wake_reason)

Q(wb)

Q(websocket)

Q(websocket)

Q(websocket)

Q(websocket)

Q(width)

Q(width)

Q(wp)

Q(wrap_socket)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write)

Q(write_pulses)

Q(write_readinto)

Q(writebit)

Q(writeblocks)

Q(writeblocks)

Q(writeblocks)

Q(writebyte)

Q(writeto)

Q(writeto_mem)

Q(writevto)

Q(zip)

Q(zip)
