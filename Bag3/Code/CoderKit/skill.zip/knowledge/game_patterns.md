# Game patterns: many players, many device types, or both

Read this whenever a game involves more than one wand, or a wand plus the icon display. The message rules it builds on are in the platform section ("Talking between devices").

## Facts that shape every multi-player game

- **Today, every wand gets the same game file.** The Box currently serves one file per device
  type for each game, so different children cannot be sent different code. Anything that differs
  between wands (caller or player, green team or blue team) is chosen **while the game runs**.
  This is how distribution works now, not a design rule; it may change.
- **Choose roles with cards.** A child taps a role card (`"caller"`, `"player"`) or a team card
  (`"green"`, `"blue"`) after the game starts. Show the chosen role on the lights straight away
  (a color or a shape) so the teacher can see who is what. Give every wand a **default role** so a
  child who taps nothing can still play.
- **One device is in charge.** When several wands could decide the same thing at once ("who won?"),
  let one device decide and announce it: the caller wand, or the icon display as referee. The
  first message of a round wins; later ones are ignored until the next round.
- **A device does not hear its own broadcast.** Update your own state directly when you send.
- **Messages can be missed.** A device in charge that sets the state ("everyone freeze") should
  repeat that state about once a second, so a wand that missed it, or joined late, catches up.
- **Every file exits** on `"stop"` / `"start_game"`, whatever its role.
- **Games repeat.** Every game celebrates a win and then starts a new round, forever, until a
  stop message (`"stop"`, `"start_game"`, an exit card, or `("end",)` in a lobby game). Never
  return from `play()` because someone won.
- **Hold actions fill a light.** Game text for any hold (a button held to start or to trigger)
  says "hold until the light fills".
- **Say how many wands it is for.** A game played on more than one wand writes
  `[GAME_SETTINGS: {"wands": N}]` after the code (platform rules), N from 2 to 4, so the practice
  window starts with that many wands. A Splat host game also gives `splat_host`; a solo Splat game gives `splats` (1-2) and `"wands": 1`.

## Designing the messages

Plan the messages before writing any file, and use exactly the same names in every file.

- **One message type per game**: the game's slug, e.g. `{"type": "frogs", ...}`. Never a reserved
  type (platform section).
- **Say who sent it and what happened**, in short keys:
  `{"type": "frogs", "from": "caller", "e": "go"}`,
  `{"type": "frogs", "from": "wand", "team": "green", "e": "goal"}`.
- **Role-specific messages** name who should act on them with a `"for"` key (`"for": "players"`),
  and each receiver ignores messages not meant for its role. Never `"to"`: it holds a device MAC
  for the icon display.
- **Send what the receiver needs**, as small plain values: an event name, a team name, a count, a
  color name or a short `[r, g, b]` list. About 240 bytes at most.
- The `mac` returned by `enow.poll()` identifies the sending device, if a game needs to tell wands
  apart (for example to count players). Most games only need the role or team.

In the reply, give each role its own short action step under **How to play** ("Caller presses to
start the music.").

## Pattern A — many wands, same game, each on its own

Every wand plays the same game independently (a shake counter, a color hunt). No messages are
needed. This is the simplest multi-player game: each child holds a wand running the same file.

## Pattern B — many wands with roles

One wand leads and the others follow (Freeze Dance: the caller starts and freezes; players dance
or hold still), or wands play on teams.

```python
# Inside the wand's play(): the role is chosen by card, with a default.
role = "player"                      # default role
...
if cmd == "caller":
    role = "caller"; leds.show_shape(SHAPE_STAR, YELLOW)
elif cmd == "player":
    role = "player"; leds.show_shape(SHAPE_HAPPY_FACE, GREEN)

# Caller: announce, and repeat the state about once a second
if role == "caller" and frame % 20 == 0:
    enow.broadcast({"type": "frogs", "from": "caller", "for": "players", "e": state})

# Player: act only on messages for players
if (msg_type == "raw" and isinstance(data, dict) and data.get("type") == "frogs"
        and data.get("for") == "players"):
    state = data.get("e")
```

Role and team cards go in `COMMANDS` and in `[NFC_CARDS: ...]`.

## Pattern C — wands with other device types

Each device type gets its own complete file under its own `[DEVICE:]` marker. Decide, for each
thing that happens, which device notices it and broadcasts, and which devices react.

Worked example — the wand and the display echo each other:

- Wand: button pressed → `enow.broadcast({"type": "<slug>", "from": "wand", "rgb": [r, g, b]})`.
- Display: `"raw"` message with `type == "<slug>"` and `from == "wand"` → show an icon in that color.
- Display: after drawing → `enow.broadcast({"type": "<slug>", "from": "icon", "shown": True})`.
- Wand: that message → a short `buz.confirm()`.

## Pattern D — many wands on teams, plus other devices

The icon display usually acts as **referee and scoreboard**: the wands report, the display
decides, and everyone reacts to the display. Based on the built-in Team Goal Race (which predates
the slug-as-type rule and uses the types `"goal"` and `"winner"`; new games use their slug):

- Wand: tap a team card to join (the built-in uses `"teamgreen"` / `"teamblue"`), shown on the
  lights.
- Wand: tap the `"goal"` card → `{"type": "<slug>", "e": "goal", "team": "green"}`.
- Display: the **first** goal message of a round wins; it shows the team's picture and broadcasts
  `{"type": "<slug>", "e": "winner", "team": "green"}`.
- Wands: on the winner message, the winning team celebrates and the others show a friendly
  "next round" color. Nobody is out.

## For young children

- **The teacher holds the leading wand** in role games, and tells the class what each light means.
- **Role and team cards should carry a picture or color**, since children cannot read the names.
- **Everyone stays in.** Being caught or losing a round shows a short, friendly signal, then the
  wand is back in the game.
