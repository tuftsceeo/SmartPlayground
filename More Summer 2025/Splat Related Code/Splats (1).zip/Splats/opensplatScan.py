
import asyncio
import logging
from bleak import BleakScanner, BleakClient
import platform

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SplatDevice:
    """Control interface for the Splat BLE device."""
    
    # Service and characteristic UUIDs
    WRITE_CHAR_UUID = "0000fff3-0000-1000-8000-00805f9b34fb"
    NOTIFY_CHAR_UUID = "0000fff4-0000-1000-8000-00805f9b34fb"
    
    # Command constants
    CMD_LED = 0x04
    CMD_CLEAR = 0x05
    
    def __init__(self, device_name="Splat"):
        """Initialize the Splat device controller.
        
        Args:
            device_name: Name of the device to connect to (default: "Splat")
        """
        self.device_name = device_name
        self.device = None
        self.client = None
    
    async def connect(self):
        """Scan for and connect to the Splat device."""
        logger.info(f"Scanning for {self.device_name} device...")
        
        devices = await BleakScanner.discover(timeout=5.0)
        
        for device in devices:
            if device.name and self.device_name in device.name:
                self.device = device
                logger.info(f"Found target device: {device.name} ({device.address})")
                break
        
        if not self.device:
            raise ValueError(f"Could not find device named '{self.device_name}'")
        
        # Connect to the device
        client_args = self.device if platform.system() == "Darwin" else self.device.address
        self.client = BleakClient(client_args)
        await self.client.connect()
        
        logger.info(f"Connected to {self.device.name}: {self.client.is_connected}")
        
        # Start notifications
        await self.client.start_notify(self.NOTIFY_CHAR_UUID, self._notification_handler)
        
        return self.client.is_connected
    
    async def disconnect(self):
        """Disconnect from the device."""
        if self.client and self.client.is_connected:
            await self.client.stop_notify(self.NOTIFY_CHAR_UUID)
            await self.client.disconnect()
            logger.info(f"Disconnected from {self.device.name}")
    
    def _notification_handler(self, sender, data):
        """Handle notifications from the device."""
        logger.info(f"Notification received: {data.hex()}")
    
    async def _send_command(self, command):
        """Send a raw command to the device."""
        if not self.client or not self.client.is_connected:
            raise RuntimeError("Not connected to the device")
        
        await self.client.write_gatt_char(self.WRITE_CHAR_UUID, command)
        logger.info(f"Sent command: {command.hex()}")
    
    async def set_led_color(self, led_index, r, g, b):
        """Set a specific LED to an RGB color.
        
        Args:
            led_index: Index of the LED (0-14)
            r: Red value (0-255)
            g: Green value (0-255)
            b: Blue value (0-255)
        """
        if not 0 <= led_index <= 14:
            raise ValueError("LED index must be between 0 and 14")
        
        if not (0 <= r <= 255 and 0 <= g <= 255 and 0 <= b <= 255):
            raise ValueError("RGB values must be between 0 and 255")
        
        command = bytes([self.CMD_LED, led_index, r, g, b])
        await self._send_command(command)
    
    async def turn_on_led(self, led_index):
        """Turn on a specific LED with default color (blue).
        
        Args:
            led_index: Index of the LED (0-14)
        """
        if not 0 <= led_index <= 14:
            raise ValueError("LED index must be between 0 and 14")
        
        command = bytes([self.CMD_LED, led_index])
        await self._send_command(command)
    
    async def clear_all_leds(self):
        """Turn off all LEDs."""
        command = bytes([self.CMD_CLEAR, 0x00])
        await self._send_command(command)
        
        # Wait a moment for the clear command to take effect
        await asyncio.sleep(0.1)
    
    async def set_all_leds(self, r, g, b):
        """Set all LEDs to the same color.
        
        This is a convenience method that sets each LED individually.
        
        Args:
            r: Red value (0-255)
            g: Green value (0-255)
            b: Blue value (0-255)
        """
        if not (0 <= r <= 255 and 0 <= g <= 255 and 0 <= b <= 255):
            raise ValueError("RGB values must be between 0 and 255")
        
        for i in range(14):  # 14 LEDs
            await self.set_led_color(i, r, g, b)
            await asyncio.sleep(0.05)  # Small delay to avoid overwhelming the device
    
    async def run_chase_pattern(self, r=255, g=0, b=0, delay=0.1):
        """Run a chase pattern on the LEDs.
        
        Args:
            r: Red value (0-255)
            g: Green value (0-255)
            b: Blue value (0-255)
            delay: Delay between steps in seconds
        """
        for i in range(14):  # 14 LEDs
            await self.clear_all_leds()
            await self.set_led_color(i, r, g, b)
            await asyncio.sleep(delay)
        
        await self.clear_all_leds()

async def main():
    """Demo application for the Splat device."""
    splat = SplatDevice()
    
    try:
        # Connect to the device
        await splat.connect()
        
        # Demo 1: Turn on each LED in sequence
        print("Demo 1: Chase pattern")
        await splat.run_chase_pattern(r=255, g=0, b=0, delay=0.2)
        
        # Demo 2: Set all LEDs to green
        print("Demo 2: All LEDs green")
        await splat.set_all_leds(0, 255, 0)
        await asyncio.sleep(2)
        
        # Demo 3: Set each LED to a different color
        print("Demo 3: Rainbow pattern")
        colors = [
            (255, 0, 0),    # Red
            (255, 127, 0),  # Orange
            (255, 255, 0),  # Yellow
            (0, 255, 0),    # Green
            (0, 0, 255),    # Blue
            (75, 0, 130),   # Indigo
            (148, 0, 211),  # Violet
        ]
        
        await splat.clear_all_leds()
        
        for i in range(7):  # First 7 LEDs
            r, g, b = colors[i % len(colors)]
            await splat.set_led_color(i, r, g, b)
            await asyncio.sleep(0.2)
        
        await asyncio.sleep(3)
        
        # Clean up
        await splat.clear_all_leds()
        
    finally:
        # Always disconnect
        await splat.disconnect()

if __name__ == "__main__":
    asyncio.run(main())

